# Correções realizadas e situação da validação

## Correções aplicadas
- O ID do pedido recém-criado é preservado na tela usando `localStorage`; não é perdido após recarregar a página.
- A descontinuação do produto deixou de aceitar `administrador=true` na URL. O endpoint agora exige HTTP Basic e perfil `ROLE_ADM`.
- A conta ADM local é configurável por `ADMIN_USERNAME` e `ADMIN_PASSWORD` (padrão acadêmico: `admin` / `admin123`). Troque a senha antes de expor o sistema.
- A fila de faturamento processa boleto, nota e e-mail em segundo plano, com status `PROCESSANDO`, `FATURADA` ou `ERRO`.
- A fatura pode ser consultada em `GET /api/hub/faturas/{id}`.
- A integração REST recebeu timeout, três tentativas e Circuit Breaker simples em memória. A criação da fatura é idempotente por pedido, apoiada por restrição única no banco.
- Os adaptadores não regeneram resultados já persistidos quando uma fatura com erro é reprocessada.
- Movimentações de estoque usam bloqueio pessimista do produto para evitar concorrência que gere saldo negativo.
- Foram adicionados testes unitários para as regras de estoque e os formatos dos adaptadores simulados.

## Validação executada neste ambiente
- Integridade e extração do ZIP: verificáveis.
- Estrutura de diretórios e arquivos Java: verificada.
- XML do `pom.xml`: validado.
- Compilação e execução dos testes Maven: **não concluídas**, pois o ambiente não conseguiu baixar a distribuição Maven de `repo.maven.apache.org`. Portanto, não afirmar que todos os testes passaram até executar `mvnw.cmd clean test` em um ambiente com acesso ao Maven Central.

## Comandos no Windows
```powershell
.\mvnw.cmd clean test
.\mvnw.cmd spring-boot:run
```
Depois, acesse `http://localhost:8080/home`.
