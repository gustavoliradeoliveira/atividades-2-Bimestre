# Projeto MVC — Estoque, pedidos e faturamento

Projeto original ampliado para as atividades 6, 7 e 8. Mantém a classe principal `MvcApplication`, o pacote `br.com.mvc`, o `HomeController`, Thymeleaf, Spring Data JPA e H2.

## Executar
- Java 21.
- Windows: `mvnw.cmd spring-boot:run`
- Linux/macOS: `./mvnw spring-boot:run`
- Tela: `http://localhost:8080/home`

## Principais endpoints

| Método | Endpoint | Finalidade |
|---|---|---|
| POST | `/api/produtos` | Cadastrar produto |
| GET | `/api/produtos` | Listar produtos |
| POST | `/api/produtos/{id}/entrada` | Entrada de estoque |
| POST | `/api/produtos/{id}/saida` | Saída de estoque |
| POST | `/api/produtos/{id}/descontinuar (HTTP Basic: usuário ADM)` | Descontinuar como ADM protegido por HTTP Basic |
| GET | `/api/estoque/movimentacoes` | Listar movimentações |
| POST | `/api/pedidos` | Criar pedido |
| POST | `/api/pedidos/{id}/fechar` | Fechar pedido e chamar Hub REST |
| POST | `/api/hub/faturas` | Criar/processar fatura no Hub |
| GET | `/api/hub/faturas/{id}` | Consultar fatura |

### Exemplos de JSON

Criar produto:
```json
{ "nome": "Teclado" }
```

Entrada/saída:
```json
{ "quantidade": 3 }
```

Criar pedido:
```json
{ "descricao": "Pedido de venda 001" }
```

Fechar pedido:
```json
{ "email": "cliente@exemplo.com" }
```

O banco H2 é persistido em `./data/mvcdb`. A console H2 está em `/h2-console` com JDBC URL `jdbc:h2:file:./data/mvcdb`, usuário `sa` e senha vazia.

As limitações e o detalhamento dos requisitos atendidos estão no `../README-ENTREGA.md` e nas pastas `Atividades`.


## Execução e segurança
Consulte `COMO-EXECUTAR.md`. A descontinuação requer HTTP Basic com perfil ADM (padrão local: admin/admin123). Configure `ADMIN_PASSWORD` antes de expor o serviço.

## Faturamento assíncrono e resiliência
O fechamento do pedido retorna o ID da fatura e inicia os adaptadores em segundo plano. Consulte `GET /api/hub/faturas/{id}`. O cliente REST possui timeout, retentativas e Circuit Breaker simples em memória.
