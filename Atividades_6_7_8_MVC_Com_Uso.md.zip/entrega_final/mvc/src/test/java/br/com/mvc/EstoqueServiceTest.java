package br.com.mvc;

import br.com.mvc.model.*;
import br.com.mvc.repository.*;
import br.com.mvc.service.EstoqueService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import java.util.Optional;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class EstoqueServiceTest {
    @Mock ProdutoRepository produtos;
    @Mock MovimentacaoRepository movimentos;
    EstoqueService service;
    @BeforeEach void setup() { service = new EstoqueService(produtos, movimentos); }

    @Test void produtoNovoIniciaIndisponivel() {
        when(produtos.save(any(Produto.class))).thenAnswer(i -> i.getArgument(0));
        Produto p = service.criar("Teclado");
        assertEquals(Produto.StatusProduto.INDISPONIVEL, p.getStatus());
        assertEquals(0, p.getEstoque());
    }
    @Test void entradaAtualizaSaldoEStatus() {
        Produto p = new Produto("Mouse"); when(produtos.findByIdComBloqueio(1L)).thenReturn(Optional.of(p)); when(produtos.save(any())).thenAnswer(i -> i.getArgument(0));
        Produto atualizado = service.entrada(1L, 5);
        assertEquals(5, atualizado.getEstoque()); assertEquals(Produto.StatusProduto.DISPONIVEL, atualizado.getStatus()); verify(movimentos).save(any(MovimentacaoEstoque.class));
    }
    @Test void saidaQueZeraEstoqueIndisponibiliza() {
        Produto p = new Produto("Mouse"); p.setEstoque(3); p.setStatus(Produto.StatusProduto.DISPONIVEL); when(produtos.findByIdComBloqueio(1L)).thenReturn(Optional.of(p)); when(produtos.save(any())).thenAnswer(i -> i.getArgument(0));
        Produto atualizado = service.saida(1L, 3); assertEquals(0, atualizado.getEstoque()); assertEquals(Produto.StatusProduto.INDISPONIVEL, atualizado.getStatus());
    }
    @Test void naoPermiteSaidaSemSaldo() {
        Produto p = new Produto("Mouse"); when(produtos.findByIdComBloqueio(1L)).thenReturn(Optional.of(p));
        assertThrows(IllegalStateException.class, () -> service.saida(1L, 1)); verify(movimentos, never()).save(any());
    }
    @Test void naoPermiteMovimentarDescontinuado() {
        Produto p = new Produto("Mouse"); p.setStatus(Produto.StatusProduto.DESCONTINUADO); when(produtos.findByIdComBloqueio(1L)).thenReturn(Optional.of(p));
        assertThrows(IllegalStateException.class, () -> service.entrada(1L, 1));
        assertThrows(IllegalStateException.class, () -> service.saida(1L, 1));
    }
    @Test void somenteAdmPodeDescontinuar() {
        assertThrows(SecurityException.class, () -> service.descontinuar(1L, false));
    }
}
