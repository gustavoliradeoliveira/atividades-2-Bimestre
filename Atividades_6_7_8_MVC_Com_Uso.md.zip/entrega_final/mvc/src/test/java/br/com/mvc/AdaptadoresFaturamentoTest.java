package br.com.mvc;

import br.com.mvc.hub.adapter.EmailSmtpSimulado;
import br.com.mvc.hub.adapter.FilaBoletoSimulada;
import br.com.mvc.hub.adapter.NotaFiscalSoapSimulada;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class AdaptadoresFaturamentoTest {
    @Test void boletoSimuladoGeraCodigoNumericoDeTamanhoValido() {
        String codigo = new FilaBoletoSimulada().enfileirarEEmitir(123L);
        assertEquals(44, codigo.length());
        assertTrue(codigo.matches("\\d{44}"));
    }
    @Test void notaFiscalGeraChaveDeAcessoCom44Digitos() {
        String chave = new NotaFiscalSoapSimulada().emitirNotaFiscalSoap(123L);
        assertEquals(44, chave.length());
        assertTrue(chave.matches("\\d{44}"));
    }
    @Test void emailGeraHashSha256Com64CaracteresHexadecimais() {
        String hash = new EmailSmtpSimulado().enviarSmtpERetornarHash(123L, "cliente@exemplo.com");
        assertEquals(64, hash.length());
        assertTrue(hash.matches("[0-9a-f]{64}"));
    }
}
