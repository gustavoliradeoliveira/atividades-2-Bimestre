package br.com.mvc.integration;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.HttpClientErrorException;
import java.util.concurrent.atomic.AtomicInteger;

@Component
public class HubRestClient {
    private final RestClient client;
    private final AtomicInteger falhas = new AtomicInteger();
    private volatile long circuitoAbertoAte = 0L;

    public HubRestClient(@Value("${hub.url:http://localhost:${server.port:8080}}") String url,
                         @Value("${hub.connect-timeout-ms:2000}") int connectTimeout,
                         @Value("${hub.read-timeout-ms:5000}") int readTimeout) {
        SimpleClientHttpRequestFactory factory = new SimpleClientHttpRequestFactory();
        factory.setConnectTimeout(connectTimeout);
        factory.setReadTimeout(readTimeout);
        this.client = RestClient.builder().baseUrl(url).requestFactory(factory).build();
    }

    public FaturaResponse faturar(Long pedidoId, String email) {
        if (System.currentTimeMillis() < circuitoAbertoAte)
            throw new IllegalStateException("Circuit breaker aberto: Hub temporariamente indisponível. Tente novamente em alguns segundos.");
        RuntimeException ultima = null;
        for (int tentativa = 1; tentativa <= 3; tentativa++) {
            try {
                FaturaResponse resposta = client.post().uri("/api/hub/faturas")
                        .body(new PedidoHub(pedidoId, email)).retrieve().body(FaturaResponse.class);
                if (resposta == null || resposta.faturaId() == null) throw new IllegalStateException("Resposta inválida do Hub.");
                falhas.set(0); circuitoAbertoAte = 0L;
                return resposta;
            } catch (HttpClientErrorException e) {
                throw new IllegalArgumentException("Hub rejeitou a solicitação: " + e.getStatusCode() + " - " + e.getResponseBodyAsString(), e);
            } catch (RestClientException | IllegalStateException e) {
                ultima = e;
                if (tentativa < 3) {
                    try { Thread.sleep(250L * tentativa); } catch (InterruptedException interrupted) { Thread.currentThread().interrupt(); break; }
                }
            }
        }
        if (falhas.incrementAndGet() >= 3) circuitoAbertoAte = System.currentTimeMillis() + 15000L;
        throw new IllegalStateException("Falha ao comunicar com o Hub após 3 tentativas.", ultima);
    }

    public record PedidoHub(Long pedidoId, String email) {}
    public record FaturaResponse(Long faturaId, Long pedidoId, String status, String codigoBarras, String chaveAcesso, String hashEmail, String erro) {}
}
