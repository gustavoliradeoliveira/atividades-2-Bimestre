package br.com.mvc.model;
import jakarta.persistence.*;
@Entity
@Table(name="produtos")
public class Produto {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @Column(nullable=false) private String nome;
 @Enumerated(EnumType.STRING) @Column(nullable=false) private StatusProduto status=StatusProduto.INDISPONIVEL;
 @Column(nullable=false) private int estoque=0;
 public enum StatusProduto { DISPONIVEL, INDISPONIVEL, DESCONTINUADO }
 public Produto() {}
 public Produto(String nome){this.nome=nome; this.status=StatusProduto.INDISPONIVEL; this.estoque=0;}
 public Long getId(){return id;} public String getNome(){return nome;} public void setNome(String nome){this.nome=nome;}
 public StatusProduto getStatus(){return status;} public void setStatus(StatusProduto status){this.status=status;}
 public int getEstoque(){return estoque;} public void setEstoque(int estoque){this.estoque=estoque;}
}
