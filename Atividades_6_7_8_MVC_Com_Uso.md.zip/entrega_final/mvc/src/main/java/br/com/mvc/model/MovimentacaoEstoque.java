package br.com.mvc.model;
import jakarta.persistence.*; import java.time.LocalDateTime;
@Entity @Table(name="movimentacoes_estoque")
public class MovimentacaoEstoque {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @Column(nullable=false) private Long produtoId; @Column(nullable=false) private int quantidade;
 @Column(nullable=false) private String tipo; @Column(nullable=false) private LocalDateTime data=LocalDateTime.now();
 public MovimentacaoEstoque() {}
 public MovimentacaoEstoque(Long produtoId,int quantidade,String tipo){this.produtoId=produtoId;this.quantidade=quantidade;this.tipo=tipo;}
 public Long getId(){return id;} public Long getProdutoId(){return produtoId;} public int getQuantidade(){return quantidade;} public String getTipo(){return tipo;} public LocalDateTime getData(){return data;}
}
