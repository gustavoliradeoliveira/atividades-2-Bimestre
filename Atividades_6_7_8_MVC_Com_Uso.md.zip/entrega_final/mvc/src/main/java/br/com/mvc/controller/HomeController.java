package br.com.mvc.controller;
import br.com.mvc.repository.*; import org.springframework.stereotype.Controller; import org.springframework.ui.Model; import org.springframework.web.bind.annotation.*;
@Controller @RequestMapping("/home") public class HomeController {
 private final ProdutoRepository produtos; private final PedidoRepository pedidos; private final MovimentacaoRepository movimentos;
 public HomeController(ProdutoRepository p,PedidoRepository pe,MovimentacaoRepository m){produtos=p;pedidos=pe;movimentos=m;}
 @GetMapping public String home(Model model){model.addAttribute("produtos",produtos.findAll());model.addAttribute("pedidos",pedidos.findAll());model.addAttribute("movimentos",movimentos.findAll());return "index";}
}
