package br.com.mvc.hub.adapter;
import br.com.mvc.hub.port.EmailPort; import org.springframework.stereotype.Component; import java.nio.charset.StandardCharsets; import java.security.MessageDigest; import java.util.HexFormat;
@Component public class EmailSmtpSimulado implements EmailPort {
 @Override public String enviarSmtpERetornarHash(Long id,String destinatario){try{String conteudo="Fatura "+id+" enviada para "+destinatario+".";return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(conteudo.getBytes(StandardCharsets.UTF_8)));}catch(Exception e){throw new IllegalStateException("Falha no adaptador SMTP simulado.",e);}}
}
