package br.com.mvc.model;
import jakarta.persistence.*;
@Entity @Table(name="pedidos")
public class Pedido {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @Column(nullable=false) private String descricao;
 @Column(nullable=false) private String status="ABERTO";
 private Long faturaId;
 public Pedido() {} public Pedido(String descricao){this.descricao=descricao;}
 public Long getId(){return id;} public String getDescricao(){return descricao;} public String getStatus(){return status;} public void setStatus(String status){this.status=status;} public Long getFaturaId(){return faturaId;} public void setFaturaId(Long faturaId){this.faturaId=faturaId;}
}
