package br.com.mvc.model;
import jakarta.persistence.*; import java.time.LocalDateTime;
@Entity @Table(name="faturas", uniqueConstraints=@UniqueConstraint(name="uk_fatura_pedido",columnNames="pedido_id"))
public class Fatura {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @Column(name="pedido_id",nullable=false) private Long pedidoId;
 private String codigoBarras; private String chaveAcesso; private String hashEmail;
 @Column(length=1000) private String erro;
 @Column(nullable=false) private String status="CRIADA";
 @Column(nullable=false) private LocalDateTime criadaEm=LocalDateTime.now();
 public Fatura() {} public Fatura(Long pedidoId){this.pedidoId=pedidoId;}
 public Long getId(){return id;} public Long getPedidoId(){return pedidoId;} public String getCodigoBarras(){return codigoBarras;} public void setCodigoBarras(String v){codigoBarras=v;}
 public String getChaveAcesso(){return chaveAcesso;} public void setChaveAcesso(String v){chaveAcesso=v;} public String getHashEmail(){return hashEmail;} public void setHashEmail(String v){hashEmail=v;}
 public String getStatus(){return status;} public void setStatus(String status){this.status=status;} public LocalDateTime getCriadaEm(){return criadaEm;}
 public String getErro(){return erro;} public void setErro(String erro){this.erro=erro;}
}
