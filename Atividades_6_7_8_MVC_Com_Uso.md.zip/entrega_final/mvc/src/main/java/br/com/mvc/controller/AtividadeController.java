package br.com.mvc.controller;
import br.com.mvc.model.*; import br.com.mvc.repository.*; import br.com.mvc.service.*; import org.springframework.web.bind.annotation.*; import java.util.*;
@RestController @RequestMapping("/api")
public class AtividadeController {
 private final EstoqueService estoque; private final ProdutoRepository produtos; private final MovimentacaoRepository movimentos; private final PedidoService pedidos; private final PedidoRepository pedidoRepo;
 public AtividadeController(EstoqueService e,ProdutoRepository p,MovimentacaoRepository m,PedidoService ps,PedidoRepository pr){estoque=e;produtos=p;movimentos=m;pedidos=ps;pedidoRepo=pr;}
 public record ProdutoInput(String nome){} public record QuantidadeInput(int quantidade){} public record PedidoInput(String descricao){} public record FecharInput(String email){}
 @PostMapping("/produtos") public Produto criarProduto(@RequestBody ProdutoInput i){return estoque.criar(i.nome());}
 @GetMapping("/produtos") public List<Produto> produtos(){return produtos.findAll();}
 @PostMapping("/produtos/{id}/entrada") public Produto entrada(@PathVariable Long id,@RequestBody QuantidadeInput i){return estoque.entrada(id,i.quantidade());}
 @PostMapping("/produtos/{id}/saida") public Produto saida(@PathVariable Long id,@RequestBody QuantidadeInput i){return estoque.saida(id,i.quantidade());}
 @PostMapping("/produtos/{id}/descontinuar") public Produto descontinuar(@PathVariable Long id){return estoque.descontinuar(id,true);}
 @GetMapping("/estoque/movimentacoes") public List<MovimentacaoEstoque> movimentos(){return movimentos.findAll();}
 @PostMapping("/pedidos") public Pedido criarPedido(@RequestBody PedidoInput i){return pedidos.criar(i.descricao());}
 @PostMapping("/pedidos/{id}/fechar") public Pedido fechar(@PathVariable Long id,@RequestBody FecharInput i){return pedidos.fechar(id,i.email());}
 @GetMapping("/pedidos") public List<Pedido> pedidos(){return pedidoRepo.findAll();}
}
