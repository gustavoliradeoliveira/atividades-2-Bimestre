package br.com.mvc.repository;
import br.com.mvc.model.MovimentacaoEstoque;
import org.springframework.data.jpa.repository.JpaRepository;
public interface MovimentacaoRepository extends JpaRepository<MovimentacaoEstoque,Long> {}
