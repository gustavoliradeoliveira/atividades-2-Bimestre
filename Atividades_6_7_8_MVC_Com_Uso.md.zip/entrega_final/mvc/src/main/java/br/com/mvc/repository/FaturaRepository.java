package br.com.mvc.repository;
import br.com.mvc.model.Fatura;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;
public interface FaturaRepository extends JpaRepository<Fatura,Long> { Optional<Fatura> findByPedidoId(Long pedidoId);}
