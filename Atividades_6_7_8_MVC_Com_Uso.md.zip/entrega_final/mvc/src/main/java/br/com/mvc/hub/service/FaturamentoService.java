package br.com.mvc.hub.service;

import br.com.mvc.model.Fatura;
import br.com.mvc.repository.FaturaRepository;
import org.springframework.stereotype.Service;

@Service
public class FaturamentoService {
    private final FaturaRepository faturas;
    private final FaturamentoWorker worker;

    public FaturamentoService(FaturaRepository faturas, FaturamentoWorker worker) {
        this.faturas = faturas;
        this.worker = worker;
    }

    public Fatura consultar(Long id) {
        return faturas.findById(id).orElseThrow(() -> new IllegalArgumentException("Fatura não encontrada."));
    }

    public synchronized Fatura faturar(Long pedidoId, String destinatario) {
        if (pedidoId == null || pedidoId <= 0) throw new IllegalArgumentException("Pedido inválido.");
        if (destinatario == null || destinatario.isBlank() || !destinatario.matches("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$"))
            throw new IllegalArgumentException("Informe um e-mail válido do cliente.");

        Fatura f = faturas.findByPedidoId(pedidoId).orElseGet(() -> faturas.save(new Fatura(pedidoId)));
        if ("FATURADA".equals(f.getStatus()) || "PROCESSANDO".equals(f.getStatus())) return f;
        f.setStatus("PROCESSANDO");
        f.setErro(null);
        f = faturas.save(f);
        try {
            worker.processar(f.getId(), destinatario);
        } catch (RuntimeException e) {
            f.setStatus("ERRO");
            f.setErro("Não foi possível enfileirar o processamento: " + e.getMessage());
            faturas.save(f);
        }
        return f;
    }
}
