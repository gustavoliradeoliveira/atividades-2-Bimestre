package br.com.mvc.hub.adapter;
import br.com.mvc.hub.port.NotaFiscalPort; import org.springframework.stereotype.Component;
@Component public class NotaFiscalSoapSimulada implements NotaFiscalPort {
 @Override public String emitirNotaFiscalSoap(Long id){StringBuilder chave=new StringBuilder("4126110000000000000055001000000001");chave.append(String.format("%08d",id));while(chave.length()<43)chave.append('0');int soma=0,peso=2;for(int i=chave.length()-1;i>=0;i--){soma+=(chave.charAt(i)-'0')*peso;peso=peso==9?2:peso+1;}int resto=soma%11;int dv=11-resto;if(dv>=10)dv=0;chave.append(dv);return chave.substring(0,44);}
}
