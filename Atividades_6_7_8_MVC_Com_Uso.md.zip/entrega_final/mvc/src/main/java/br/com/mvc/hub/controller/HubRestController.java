package br.com.mvc.hub.controller;
import br.com.mvc.hub.service.FaturamentoService; import br.com.mvc.model.Fatura; import org.springframework.http.HttpStatus; import org.springframework.web.bind.annotation.*;
@RestController @RequestMapping("/api/hub/faturas")
public class HubRestController {
 private final FaturamentoService faturamento; public HubRestController(FaturamentoService faturamento){this.faturamento=faturamento;}
 public record PedidoFaturamentoRequest(Long pedidoId,String email){} public record FaturaResponse(Long faturaId,Long pedidoId,String status,String codigoBarras,String chaveAcesso,String hashEmail,String erro){}
 @PostMapping @ResponseStatus(HttpStatus.CREATED) public FaturaResponse faturar(@RequestBody PedidoFaturamentoRequest request){Fatura f=faturamento.faturar(request.pedidoId(),request.email());return new FaturaResponse(f.getId(),f.getPedidoId(),f.getStatus(),f.getCodigoBarras(),f.getChaveAcesso(),f.getHashEmail(),f.getErro());}
 @GetMapping("/{id}") public Fatura consultar(@PathVariable Long id){return faturamento.consultar(id);}
}
