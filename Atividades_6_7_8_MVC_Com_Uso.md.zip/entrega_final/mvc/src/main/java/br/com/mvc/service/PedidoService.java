package br.com.mvc.service;

import br.com.mvc.model.Pedido;
import br.com.mvc.repository.PedidoRepository;
import br.com.mvc.integration.HubRestClient;
import org.springframework.stereotype.Service;

@Service
public class PedidoService {
    private final PedidoRepository pedidos;
    private final HubRestClient hub;

    public PedidoService(PedidoRepository pedidos, HubRestClient hub) { this.pedidos = pedidos; this.hub = hub; }

    public Pedido criar(String descricao) {
        if (descricao == null || descricao.isBlank()) throw new IllegalArgumentException("Informe a descrição do pedido.");
        return pedidos.save(new Pedido(descricao.trim()));
    }

    public synchronized Pedido fechar(Long id, String email) {
        Pedido p = pedidos.findById(id).orElseThrow(() -> new IllegalArgumentException("Pedido não encontrado."));
        if ("FECHADO".equals(p.getStatus())) return p;
        if ("PROCESSANDO_FATURAMENTO".equals(p.getStatus())) throw new IllegalStateException("Pedido já está em processamento. Consulte novamente em alguns instantes.");
        p.setStatus("PROCESSANDO_FATURAMENTO");
        pedidos.save(p);
        try {
            var f = hub.faturar(p.getId(), email);
            if (f == null || f.faturaId() == null) throw new IllegalStateException("Hub não retornou o ID da fatura.");
            p.setFaturaId(f.faturaId());
            p.setStatus("FECHADO");
            return pedidos.save(p);
        } catch (Exception e) {
            p.setStatus("FALHA_FATURAMENTO");
            pedidos.save(p);
            throw new IllegalStateException("Não foi possível confirmar o faturamento. O pedido foi preservado e pode ser reprocessado sem duplicar a fatura.", e);
        }
    }
}
