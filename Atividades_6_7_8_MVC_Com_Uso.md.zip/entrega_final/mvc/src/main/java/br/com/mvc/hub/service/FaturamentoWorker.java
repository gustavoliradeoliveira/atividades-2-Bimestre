package br.com.mvc.hub.service;

import br.com.mvc.hub.port.EmailPort;
import br.com.mvc.hub.port.FilaBoletoPort;
import br.com.mvc.hub.port.NotaFiscalPort;
import br.com.mvc.model.Fatura;
import br.com.mvc.repository.FaturaRepository;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@Service
public class FaturamentoWorker {
    private final FaturaRepository faturas;
    private final FilaBoletoPort boleto;
    private final NotaFiscalPort nota;
    private final EmailPort email;

    public FaturamentoWorker(FaturaRepository faturas, FilaBoletoPort boleto, NotaFiscalPort nota, EmailPort email) {
        this.faturas = faturas; this.boleto = boleto; this.nota = nota; this.email = email;
    }

    @Async("faturamentoExecutor")
    public void processar(Long id, String destinatario) {
        Fatura f = faturas.findById(id).orElse(null);
        if (f == null || "FATURADA".equals(f.getStatus())) return;
        try {
            if (f.getCodigoBarras() == null) f.setCodigoBarras(boleto.enfileirarEEmitir(id));
            if (f.getChaveAcesso() == null) f.setChaveAcesso(nota.emitirNotaFiscalSoap(id));
            if (f.getHashEmail() == null) f.setHashEmail(email.enviarSmtpERetornarHash(id, destinatario));
            f.setStatus("FATURADA");
            f.setErro(null);
        } catch (Exception e) {
            f.setStatus("ERRO");
            f.setErro(e.getMessage() == null ? "Falha no processamento da fatura." : e.getMessage());
        }
        faturas.save(f);
    }
}
