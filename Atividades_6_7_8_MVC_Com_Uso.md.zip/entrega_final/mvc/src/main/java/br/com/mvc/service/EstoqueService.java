package br.com.mvc.service;
import br.com.mvc.model.*; import br.com.mvc.repository.*; import org.springframework.stereotype.Service; import org.springframework.transaction.annotation.Transactional;
@Service
public class EstoqueService {
 private final ProdutoRepository produtos; private final MovimentacaoRepository movimentos;
 public EstoqueService(ProdutoRepository produtos,MovimentacaoRepository movimentos){this.produtos=produtos;this.movimentos=movimentos;}
 @Transactional public Produto criar(String nome){if(nome==null||nome.isBlank())throw new IllegalArgumentException("Informe o nome do produto.");return produtos.save(new Produto(nome.trim()));}
 @Transactional public Produto entrada(Long id,int quantidade){validarQuantidade(quantidade);Produto p=buscar(id);validarNaoDescontinuado(p);try { p.setEstoque(Math.addExact(p.getEstoque(), quantidade)); } catch (ArithmeticException e) { throw new IllegalArgumentException("A quantidade ultrapassa o limite permitido."); }p.setStatus(Produto.StatusProduto.DISPONIVEL);movimentos.save(new MovimentacaoEstoque(id,quantidade,"ENTRADA"));return produtos.save(p);}
 @Transactional public Produto saida(Long id,int quantidade){validarQuantidade(quantidade);Produto p=buscar(id);validarNaoDescontinuado(p);if(p.getEstoque()<quantidade)throw new IllegalStateException("Estoque insuficiente para realizar a saída.");p.setEstoque(p.getEstoque()-quantidade);p.setStatus(p.getEstoque()==0?Produto.StatusProduto.INDISPONIVEL:Produto.StatusProduto.DISPONIVEL);movimentos.save(new MovimentacaoEstoque(id,quantidade,"SAIDA"));return produtos.save(p);}
 @Transactional public Produto descontinuar(Long id,boolean administrador){if(!administrador)throw new SecurityException("Somente o perfil ADM pode descontinuar um produto.");Produto p=buscar(id);p.setStatus(Produto.StatusProduto.DESCONTINUADO);return produtos.save(p);}
 private Produto buscar(Long id){return produtos.findByIdComBloqueio(id).orElseThrow(()->new IllegalArgumentException("Produto não encontrado."));}
 private void validarNaoDescontinuado(Produto p){if(p.getStatus()==Produto.StatusProduto.DESCONTINUADO)throw new IllegalStateException("Produto descontinuado não pode ser movimentado.");}
 private void validarQuantidade(int q){if(q<=0)throw new IllegalArgumentException("A quantidade deve ser maior que zero.");}
}
