package br.com.mvc.hub.adapter;

import br.com.mvc.hub.port.FilaBoletoPort;
import org.springframework.stereotype.Component;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;

@Component
public class FilaBoletoSimulada implements FilaBoletoPort {
    private final ExecutorService fila = Executors.newSingleThreadExecutor(r -> {
        Thread thread = new Thread(r, "fila-boleto-simulada");
        thread.setDaemon(true);
        return thread;
    });
    private final AtomicLong sequencia = new AtomicLong(1);

    @Override
    public String enfileirarEEmitir(Long faturaId) {
        try {
            return fila.submit(() -> {
                StringBuilder codigo = new StringBuilder("3419")
                        .append(String.format("%010d", faturaId))
                        .append(String.format("%010d", sequencia.getAndIncrement()));
                while (codigo.length() < 43) {
                    codigo.append('0');
                }
                int soma = 0;
                int peso = 2;
                for (int i = codigo.length() - 1; i >= 0; i--) {
                    soma += (codigo.charAt(i) - '0') * peso;
                    peso = peso == 9 ? 2 : peso + 1;
                }
                int digito = 11 - (soma % 11);
                if (digito >= 10) digito = 0;
                return codigo.append(digito).toString();
            }).get(5, TimeUnit.SECONDS);
        } catch (Exception e) {
            throw new IllegalStateException("Falha na fila simulada de boletos.", e);
        }
    }
}
