# Uso.md — Como executar e utilizar o projeto MVC

Este guia explica como preparar, iniciar e testar localmente o projeto MVC das atividades 6, 7 e 8.

## 1. Requisitos

- Windows 10/11 (os comandos abaixo usam PowerShell).
- JDK 21 instalado e configurado no `PATH`.
- Conexão com a internet na primeira execução, para que o Maven Wrapper baixe o Maven e as dependências do projeto.
- IntelliJ IDEA ou VS Code (opcional; também é possível executar pelo terminal).

Confira a instalação do Java:

```powershell
java -version
```

A versão apresentada deve ser 21. Se o comando não for reconhecido, instale o JDK 21 e configure a variável `JAVA_HOME` e o `PATH`.

## 2. Abrir a pasta correta

1. Extraia o arquivo ZIP do projeto.
2. Abra a pasta `entrega_final/mvc` — é nela que estão o `pom.xml` e o arquivo `mvnw.cmd`.
3. Abra um terminal nessa pasta.

A estrutura correta deve conter, entre outros, estes arquivos:

```text
mvc/
├── pom.xml
├── mvnw
├── mvnw.cmd
├── Uso.md
└── src/
```

## 3. Executar os testes

No PowerShell, dentro da pasta `mvc`, execute:

```powershell
.\mvnw.cmd clean test
```

O primeiro uso pode demorar porque o Maven Wrapper e as dependências precisam ser baixados. Aguarde o término do comando.

- Se aparecer `BUILD SUCCESS`, a compilação e os testes automatizados terminaram com sucesso.
- Se aparecer `BUILD FAILURE`, consulte a primeira mensagem de erro relevante no terminal. Verifique também se o JDK 21 está ativo e se há conexão com a internet.

## 4. Iniciar a aplicação

Ainda na pasta `mvc`, execute:

```powershell
.\mvnw.cmd spring-boot:run
```

Mantenha esse terminal aberto enquanto estiver utilizando o sistema. Quando o Spring Boot iniciar, procure no terminal uma mensagem indicando que a aplicação foi iniciada e que o servidor está na porta `8080`.

Abra no navegador:

**http://localhost:8080/home**

Para encerrar a aplicação, volte ao terminal e pressione `Ctrl + C`.

## 5. Banco de dados

O projeto utiliza o banco H2 em arquivo, sem exigir instalação separada de PostgreSQL ou MySQL. Os dados são armazenados localmente em `mvc/data/mvcdb` (o caminho é relativo à pasta de execução).

Configuração padrão:

- JDBC URL: `jdbc:h2:file:./data/mvcdb`
- Usuário: `sa`
- Senha: vazia

O console do H2 fica em **http://localhost:8080/h2-console**. A rota é protegida pelo perfil ADM; entre com as credenciais de administrador descritas na seção seguinte. No formulário do console, informe a JDBC URL acima, usuário `sa` e senha vazia.

## 6. Acesso de administrador

Para a demonstração local, a configuração padrão é:

- Usuário: `admin`
- Senha: `admin123`

A ação de descontinuar um produto exige autenticação HTTP Basic com perfil `ADM`. Ao clicar em **Descontinuar (ADM)** na tela, informe essas credenciais quando solicitadas.

> A conta padrão existe apenas para demonstração acadêmica. Antes de disponibilizar o sistema em uma rede ou ambiente externo, defina uma senha forte. No PowerShell, antes de iniciar a aplicação, execute:

```powershell
$env:ADMIN_USERNAME = "administrador"
$env:ADMIN_PASSWORD = "defina-uma-senha-forte"
.\mvnw.cmd spring-boot:run
```

As variáveis valem para a janela atual do PowerShell. Não compartilhe a senha nem publique credenciais reais em repositórios.

## 7. Utilizar a tela principal

Na página `http://localhost:8080/home`, estão disponíveis os fluxos principais:

### Atividade 6 — Estoque

1. Em **Cadastrar produto**, informe o nome e clique em **Cadastrar**. O produto é criado com estoque zero e status `INDISPONIVEL`.
2. Em **Movimentar estoque**, informe o ID do produto e uma quantidade inteira positiva.
3. Clique em **Entrada** para aumentar o saldo. Quando o saldo fica maior que zero, o status passa para `DISPONIVEL`.
4. Clique em **Saída** para diminuir o saldo. O sistema bloqueia a saída maior que o saldo disponível; quando o saldo chega a zero, o status passa para `INDISPONIVEL`.
5. Para descontinuar, informe o ID e clique em **Descontinuar (ADM)**. A operação exige autenticação ADM. Produtos descontinuados não podem receber entradas nem saídas.

As tabelas da página exibem produtos, saldos, status e movimentações registradas. Após operações, a tela pode ser atualizada para mostrar os dados persistidos.

### Atividades 7 e 8 — Pedido e faturamento

1. Em **Criar e fechar pedido**, informe uma descrição e clique em **Criar pedido**.
2. O ID criado é preenchido no campo de pedido e mantido no navegador.
3. Informe o e-mail do cliente e clique em **Fechar e faturar**.
4. O MVC envia a solicitação ao Hub REST. O ID da fatura retornado é associado ao pedido.
5. O boleto, a nota fiscal e o e-mail são processados por adaptadores simulados em segundo plano.
6. Clique em **Consultar processamento** para consultar a fatura. Repita a consulta até o status ficar `FATURADA` ou `ERRO`.

Os adaptadores são simulações acadêmicas: não emitem boleto bancário real, não transmitem nota fiscal a uma SEFAZ e não enviam e-mail por um servidor SMTP real.

## 8. Endpoints REST úteis

Os exemplos abaixo podem ser executados em outro PowerShell enquanto a aplicação estiver rodando.

Criar produto:

```powershell
Invoke-RestMethod -Method Post -Uri http://localhost:8080/api/produtos -ContentType 'application/json' -Body '{"nome":"Teclado"}'
```

Listar produtos:

```powershell
Invoke-RestMethod -Method Get -Uri http://localhost:8080/api/produtos
```

Registrar entrada (substitua `1` pelo ID real):

```powershell
Invoke-RestMethod -Method Post -Uri http://localhost:8080/api/produtos/1/entrada -ContentType 'application/json' -Body '{"quantidade":5}'
```

Registrar saída:

```powershell
Invoke-RestMethod -Method Post -Uri http://localhost:8080/api/produtos/1/saida -ContentType 'application/json' -Body '{"quantidade":2}'
```

Descontinuar produto como ADM:

```powershell
$credencial = Get-Credential
Invoke-RestMethod -Method Post -Uri http://localhost:8080/api/produtos/1/descontinuar -Credential $credencial
```

Criar pedido:

```powershell
Invoke-RestMethod -Method Post -Uri http://localhost:8080/api/pedidos -ContentType 'application/json' -Body '{"descricao":"Pedido de demonstração"}'
```

Fechar pedido (substitua `1` pelo ID real):

```powershell
Invoke-RestMethod -Method Post -Uri http://localhost:8080/api/pedidos/1/fechar -ContentType 'application/json' -Body '{"email":"cliente@exemplo.com"}'
```

Consultar fatura (substitua `1` pelo ID retornado):

```powershell
Invoke-RestMethod -Method Get -Uri http://localhost:8080/api/hub/faturas/1
```

## 9. Problemas comuns

- **`java` não é reconhecido:** instale o JDK 21 e configure `JAVA_HOME` e `PATH`.
- **Erro ao baixar Maven ou dependências:** confira a conexão com a internet, proxy ou firewall e tente novamente.
- **Porta 8080 ocupada:** encerre a aplicação que já utiliza a porta ou altere `server.port` em `src/main/resources/application.properties`.
- **Acesso negado ao descontinuar produto ou abrir o console H2:** use as credenciais ADM configuradas no ambiente.
- **Fatura ainda `PROCESSANDO`:** aguarde alguns instantes e consulte novamente. Os adaptadores são executados em segundo plano.
- **Fatura com status `ERRO`:** consulte o campo de erro retornado pela API e os logs exibidos no terminal da aplicação.

## 10. Observações

- O projeto utiliza Java 21, Spring Boot, Spring Data JPA, Thymeleaf, Spring Security e H2, conforme o `pom.xml` e `application.properties`.
- O Hub é acessado pela aplicação na URL local configurada em `hub.url`.
- Este documento descreve como executar e testar os fluxos disponibilizados no código. A execução bem-sucedida deve ser confirmada no computador em que o projeto for iniciado, executando primeiro `clean test` e depois `spring-boot:run`.
