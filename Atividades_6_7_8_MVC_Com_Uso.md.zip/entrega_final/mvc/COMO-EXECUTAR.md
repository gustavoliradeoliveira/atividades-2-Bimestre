# Como executar no Windows

1. Instale o JDK 21.
2. Abra esta pasta `mvc` no IntelliJ IDEA ou terminal.
3. Execute `mvnw.cmd clean test`.
4. Execute `mvnw.cmd spring-boot:run`.
5. Acesse http://localhost:8080/home.

## Credencial de demonstração ADM
- Usuário: `admin`
- Senha: `admin123`
- Para alterar antes de executar: PowerShell `$env:ADMIN_PASSWORD="sua-senha-forte"` e, opcionalmente, `$env:ADMIN_USERNAME="seu-usuario"`.

A ação de descontinuar produto solicita autenticação HTTP Basic. Esta conta em memória é apenas para demonstração acadêmica; um sistema real deve utilizar usuários e perfis persistidos.

## Faturamento assíncrono
Ao fechar um pedido, a fatura é criada e o ID retornado imediatamente. Os adaptadores simulados processam em segundo plano. Consulte `GET /api/hub/faturas/{id}` até o status ficar `FATURADA` ou `ERRO`.

## Banco de dados
O projeto utiliza H2 em arquivo na pasta `data`. O console, quando habilitado, fica em http://localhost:8080/h2-console. JDBC URL: `jdbc:h2:file:./data/mvcdb`; usuário `sa`; senha vazia.
