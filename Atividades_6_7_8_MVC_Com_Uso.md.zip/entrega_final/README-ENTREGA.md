# Entrega — Atividades 6, 7 e 8

Esta entrega contém somente os enunciados/artefatos das atividades 6, 7 e 8 e o projeto MVC original ampliado para implementar as funcionalidades pedidas.

## Estrutura
- `mvc/` — projeto Spring Boot original, preservando o pacote `br.com.mvc`, a classe `MvcApplication`, o `HomeController`, o template `index.html` e o uso de Thymeleaf/JPA/H2. Foram acrescentados controllers, models, repositories, services, integração REST e módulo do Hub.
- `Atividades/aula-6/` — README e quatro diagramas Mermaid.
- `Atividades/aula-7/` — README e diagrama da arquitetura hexagonal.
- `Atividades/aula-8/` — análise dos dois problemas de integração e suas soluções.

## Como executar
Requisitos: Java 21 e Maven (ou Maven Wrapper).

No Windows: `cd mvc` e execute `mvnw.cmd spring-boot:run`.
No Linux/macOS: `cd mvc` e execute `./mvnw spring-boot:run`.

Acesse `http://localhost:8080/home`. O H2 Console fica em `http://localhost:8080/h2-console` (JDBC URL: `jdbc:h2:file:./data/mvcdb`, usuário `sa`, senha vazia).

## API
- Estoque: `GET/POST /api/produtos`, `POST /api/produtos/{id}/entrada`, `POST /api/produtos/{id}/saida`, `POST /api/produtos/{id}/descontinuar (HTTP Basic ADM)`.
- Pedidos: `POST /api/pedidos`, `POST /api/pedidos/{id}/fechar`.
- Hub: `POST /api/hub/faturas`, `GET /api/hub/faturas/{id}`.

## Limitações transparentes
- Adaptadores de boleto, SOAP e SMTP são simulados, conforme o enunciado da aula 7.
- A fila de boleto é uma fila local em memória, não um broker externo.
- O projeto original não contém login/perfis; a indicação ADM foi simulada por parâmetro e não representa controle de acesso seguro.
- MVC e Hub estão organizados em módulos/pacotes dentro da mesma aplicação Spring Boot para manter o projeto-base e permitir a demonstração local. O cliente MVC faz chamada HTTP REST ao endpoint do Hub na mesma aplicação.
- Circuit Breaker e retentativas são discutidos no relatório da aula 8, não implementados como mecanismo executável.


## Correções de robustez
- Ação de descontinuação protegida por HTTP Basic e perfil ROLE_ADM (usuário padrão de demonstração: admin; senha padrão: admin123; altere ADMIN_PASSWORD).
- Processamento de boleto, nota e e-mail executado em segundo plano; consulte GET /api/hub/faturas/{id} para acompanhar o status.
- Integração REST com timeout, até 3 tentativas e Circuit Breaker temporário após falhas consecutivas.
- ID do pedido preservado na tela via armazenamento local do navegador.
- Bloqueio pessimista do registro do produto durante movimentações para evitar saídas concorrentes acima do saldo.
- Testes unitários adicionados para as regras centrais do estoque.
