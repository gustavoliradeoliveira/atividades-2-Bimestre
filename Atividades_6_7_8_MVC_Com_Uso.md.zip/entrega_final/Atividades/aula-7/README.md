# Aula 7 — Hub de integrações e faturamento

O módulo `br.com.mvc.hub` organiza o núcleo de faturamento, portas de saída e adaptadores simulados, seguindo a separação da arquitetura hexagonal.

## Fluxo
1. O adaptador de entrada REST recebe `pedidoId` e `email`.
2. O serviço de aplicação cria/persiste a fatura e usa o ID gerado nas integrações.
3. A porta `FilaBoletoPort` é atendida por `FilaBoletoSimulada`, que usa uma fila local em memória e produz um código de barras simulado.
4. A porta `NotaFiscalPort` é atendida por `NotaFiscalSoapSimulada`, que simula a chamada SOAP e produz uma chave numérica de 44 dígitos.
5. A porta `EmailPort` é atendida por `EmailSmtpSimulado`, que simula o envio SMTP e guarda o SHA-256 do conteúdo do e-mail.
6. A fatura é atualizada com os três resultados e status `FATURADA`.

## Endpoint
`POST /api/hub/faturas`

```json
{ "pedidoId": 10, "email": "cliente@exemplo.com" }
```

A resposta contém `faturaId`, `pedidoId`, `status`, `codigoBarras`, `chaveAcesso` e `hashEmail`. O endpoint `GET /api/hub/faturas/{id}` consulta uma fatura.

## Observação importante
Os adaptadores são simulados, conforme solicitado no enunciado. A fila é local/em memória, não um broker externo como RabbitMQ ou Kafka; SOAP e SMTP não realizam chamadas para provedores reais. A chave de acesso é um valor de demonstração com 44 dígitos, não uma NF-e autorizada pela SEFAZ.


### Processamento assíncrono
A API persiste a fatura e retorna seu identificador imediatamente com status `PROCESSANDO`. Os adaptadores simulados são executados em fila de segundo plano. Consulte `GET /api/hub/faturas/{id}` até o status mudar para `FATURADA` ou `ERRO`. Uma fatura em `ERRO` pode ser reenviada usando novamente o pedido, sem criar outra fatura para o mesmo pedido.
