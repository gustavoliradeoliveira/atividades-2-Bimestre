# Aula 6 — Módulo de estoque

Implementação no projeto `mvc`, mantendo o pacote base `br.com.mvc` e a estrutura Spring Boot original.

## Regras implementadas
- Produto novo inicia com saldo `0` e status `INDISPONIVEL`.
- Entrada exige quantidade positiva; soma ao saldo e altera o status para `DISPONIVEL`.
- Saída exige quantidade positiva e saldo suficiente; quando o saldo chega a zero, status passa a `INDISPONIVEL`.
- Produto `DESCONTINUADO` não aceita entrada nem saída.
- A operação de descontinuar verifica a indicação de administrador.
- Cada entrada/saída gera um registro em `movimentacoes_estoque`.

## Diagramas Mermaid e anexos visuais
Os arquivos `.mmd` são as fontes editáveis dos diagramas. As imagens PNG são anexos visuais em português, para leitura rápida e inclusão em documentos/apresentações.

### 1. Sequência — entrada de estoque
Fonte: `sequencia-entrada-estoque.mmd`

![Diagrama de sequência — entrada de estoque](imagens/01-sequencia-entrada.png)

### 2. Sequência — saída de estoque
Fonte: `sequencia-saida-estoque.mmd`

![Diagrama de sequência — saída de estoque](imagens/02-sequencia-saida.png)

### 3. Atividades — saída de estoque
Fonte: `atividades-saida-estoque.mmd`

![Diagrama de atividades — saída de estoque](imagens/03-atividade-saida.png)

### 4. Estados — produto
Fonte: `estados-produto.mmd`

![Diagrama de estados — produto](imagens/04-estados-produto.png)

## Rotas REST
- `POST /api/produtos` — JSON: `{ "nome": "Teclado" }`
- `GET /api/produtos`
- `POST /api/produtos/{id}/entrada` — JSON: `{ "quantidade": 5 }`
- `POST /api/produtos/{id}/saida` — JSON: `{ "quantidade": 2 }`
- `POST /api/produtos/{id}/descontinuar` (requer HTTP Basic com perfil ADM)
- `GET /api/estoque/movimentacoes`

A tela de operação está em `/home`.

> A descontinuação exige autenticação HTTP Basic com perfil `ROLE_ADM`. Para demonstração local, o usuário padrão é `admin` e a senha padrão é `admin123`; altere a senha por `ADMIN_PASSWORD` antes de qualquer exposição externa.
