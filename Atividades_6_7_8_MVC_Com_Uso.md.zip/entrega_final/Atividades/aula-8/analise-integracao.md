# Aula 8 — Integração da venda com o Hub de Faturamento

## Implementação

Ao fechar um pedido, `PedidoService` altera o status para `PROCESSANDO_FATURAMENTO`, chama `HubRestClient` por REST e envia o identificador do pedido e o e-mail do cliente. O Hub responde com o identificador da fatura. A venda grava esse identificador em `Pedido.faturaId` e altera o status para `FECHADO` quando o Hub confirma a criação da fatura. Os adaptadores de boleto, nota fiscal e e-mail continuam em processamento assíncrono; o status final deve ser consultado pela API do Hub.

Se a chamada falhar, o pedido permanece salvo com status `FALHA_FATURAMENTO`, sem apagar o pedido. A aplicação informa que o faturamento não foi confirmado e permite nova tentativa.

## Problema 1 — Timeout ou indisponibilidade do Hub

**O que acontece com o pedido:** a venda pode não receber a resposta dentro do tempo esperado. O Hub pode estar indisponível ou até ter concluído o faturamento sem que a resposta chegue à venda. O pedido não deve ser considerado fechado enquanto não houver confirmação do ID da fatura; na implementação, fica com `FALHA_FATURAMENTO`.

**O que o negócio percebe:** pedido criado, mas fechamento/faturamento pendente; o cliente pode não receber confirmação e a equipe pode precisar verificar o pedido.

**Solução:** timeout controlado, retentativas com intervalo progressivo e Circuit Breaker. Timeout limita o tempo de espera; retentativas tratam falhas transitórias; Circuit Breaker interrompe chamadas quando o Hub apresenta falhas repetidas, evitando sobrecarregar o serviço. A atuação ocorre no cliente REST da aplicação de vendas (`HubRestClient`) e na política de chamada do `PedidoService`.

## Problema 2 — Resposta perdida e repetição da solicitação

**O que acontece com o pedido:** o Hub pode criar a fatura, mas a resposta REST pode se perder. Se a venda repetir a solicitação sem controle, pode gerar uma segunda fatura para o mesmo pedido.

**O que o negócio percebe:** risco de cobrança ou emissão duplicada, divergência entre pedido e faturamento e necessidade de conciliação.

**Solução:** idempotência usando o identificador do pedido como chave de negócio. O Hub consulta se já existe fatura para aquele `pedidoId` e reutiliza a fatura existente em vez de criar outra. A restrição única no banco reforça a regra. A atuação ocorre no serviço de faturamento e na persistência do Hub.

## O que está demonstrado no código

- Chamada REST da venda para o Hub.
- Persistência do `faturaId` no pedido quando há confirmação.
- Status de falha quando a chamada não é concluída.
- Reutilização de fatura pelo mesmo `pedidoId` e restrição única para evitar duplicidade.

O Circuit Breaker e a política de retentativas são apresentados como soluções arquiteturais na análise, mas não foram adicionados como dependências/implementações executáveis nesta entrega. O timeout padrão do cliente HTTP depende da configuração do cliente/ambiente.


## Proteções implementadas no cliente REST
A chamada ao Hub possui timeout de conexão e leitura, até três tentativas com espera progressiva e Circuit Breaker que abre temporariamente após falhas consecutivas. O Hub garante idempotência por pedido com restrição única para evitar duplicação de faturas em retentativas.
