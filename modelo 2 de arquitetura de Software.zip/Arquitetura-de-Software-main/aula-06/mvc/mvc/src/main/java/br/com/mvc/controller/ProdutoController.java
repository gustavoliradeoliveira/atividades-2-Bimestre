package br.com.mvc.controller;

import br.com.mvc.model.Produto;
import br.com.mvc.service.ProdutoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/produtos")
public class ProdutoController {

    @Autowired
    private ProdutoService produtoService;

    @GetMapping
    public String listar(Model model) {
        model.addAttribute("produtos", produtoService.listarTodos());
        return "produto/lista";
    }

    @GetMapping("/novo")
    public String formularioNovo(Model model) {
        model.addAttribute("produto", new Produto());
        return "produto/formulario";
    }

    @PostMapping("/salvar")
    public String salvar(@ModelAttribute Produto produto) {
        produtoService.salvar(produto);
        return "redirect:/produtos";
    }

    @PostMapping("/{id}/descontinuar")
    public String descontinuar(@PathVariable Long id, @RequestParam boolean isAdmin) {
        try {
            produtoService.descontinuarProduto(id, isAdmin);
        } catch (Exception e) {
            // Tratar erro de permissão ou estado
        }
        return "redirect:/produtos";
    }
}