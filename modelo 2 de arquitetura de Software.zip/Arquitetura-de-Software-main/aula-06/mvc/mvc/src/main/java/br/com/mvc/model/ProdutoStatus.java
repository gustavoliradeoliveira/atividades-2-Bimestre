package br.com.mvc.model;

public enum ProdutoStatus {
    INDISPONÍVEL,
    DISPONÍVEL,
    DESCONTINUADO
}