package br.com.mvc.controller;

import br.com.mvc.service.ProdutoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/estoque")
public class EstoqueController {

    @Autowired
    private ProdutoService produtoService;

    @GetMapping
    public String paginaEstoque(Model model) {
        model.addAttribute("produtos", produtoService.listarTodos());
        return "estoque/gerenciar";
    }

    @PostMapping("/entrada")
    public String entrada(@RequestParam Long produtoId, @RequestParam int quantidade) {
        try {
            produtoService.entradaEstoque(produtoId, quantidade);
        } catch (Exception e) {
            // Tratar mensagem de erro na view se necessário
        }
        return "redirect:/estoque";
    }

    @PostMapping("/saida")
    public String saida(@RequestParam Long produtoId, @RequestParam int quantidade) {
        try {
            produtoService.saidaEstoque(produtoId, quantidade);
        } catch (Exception e) {
            // Tratar mensagem de erro na view se necessário
        }
        return "redirect:/estoque";
    }
}