package br.com.mvc.model;

import jakarta.persistence.*;

@Entity
@Table(name = "produtos")
public class Produto {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nome;
    
    private int quantidadeEstoque;

    @Enumerated(EnumType.STRING)
    private ProdutoStatus status = ProdutoStatus.INDISPONÍVEL; // Inicia como INDISPONÍVEL

    // Construtores
    public Produto() {
        this.status = ProdutoStatus.INDISPONÍVEL;
        this.quantidadeEstoque = 0;
    }

    public Produto(String nome) {
        this.nome = nome;
        this.quantidadeEstoque = 0;
        this.status = ProdutoStatus.INDISPONÍVEL;
    }

    // Getters e Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getQuantidadeEstoque() {
        return quantidadeEstoque;
    }

    public void setQuantidadeEstoque(int quantidadeEstoque) {
        this.quantidadeEstoque = quantidadeEstoque;
        atualizarStatusPorEstoque();
    }

    public ProdutoStatus getStatus() {
        return status;
    }

    public void setStatus(ProdutoStatus status) {
        this.status = status;
    }

    // Regra automática de status baseada no estoque (se não estiver descontinuado)
    public void atualizarStatusPorEstoque() {
        if (this.status != ProdutoStatus.DESCONTINUADO) {
            if (this.quantidadeEstoque > 0) {
                this.status = ProdutoStatus.DISPONÍVEL;
            } else {
                this.status = ProdutoStatus.INDISPONÍVEL;
            }
        }
    }
}