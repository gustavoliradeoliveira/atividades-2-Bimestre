package br.com.mvc.service;

import br.com.mvc.model.Produto;
import br.com.mvc.model.ProdutoStatus;
import br.com.mvc.repository.ProdutoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProdutoService {

    @Autowired
    private ProdutoRepository produtoRepository;

    public List<Produto> listarTodos() {
        return produtoRepository.findAll();
    }

    public Optional<Produto> buscarPorId(Long id) {
        return produtoRepository.findById(id);
    }

    public Produto salvar(Produto produto) {
        if (produto.getId() == null) {
            produto.setStatus(ProdutoStatus.INDISPONÍVEL);
            produto.setQuantidadeEstoque(0);
        }
        return produtoRepository.save(produto);
    }

    // Regra: Só o ADM pode descontinuar
    public void descontinuarProduto(Long id, boolean isAdmin) {
        if (!isAdmin) {
            throw new SecurityException("Apenas o Administrador pode descontinuar um produto.");
        }
        Produto produto = produtoRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Produto não encontrado."));
        
        produto.setStatus(ProdutoStatus.DESCONTINUADO);
        produtoRepository.save(produto);
    }

    // Rotina de Entrada de Estoque
    public void entradaEstoque(Long id, int quantidade) {
        Produto produto = produtoRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Produto não encontrado."));

        if (produto.getStatus() == ProdutoStatus.DESCONTINUADO) {
            throw new IllegalStateException("Produto descontinuado não pode ser manipulado no estoque.");
        }

        if (quantidade <= 0) {
            throw new IllegalArgumentException("A quantidade de entrada deve ser maior que zero.");
        }

        produto.setQuantidadeEstoque(produto.getQuantidadeEstoque() + quantidade);
        produtoRepository.save(produto);
    }

    // Rotina de Saída de Estoque
    public void saidaEstoque(Long id, int quantidade) {
        Produto produto = produtoRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Produto não encontrado."));

        if (produto.getStatus() == ProdutoStatus.DESCONTINUADO) {
            throw new IllegalStateException("Produto descontinuado não pode ser manipulado no estoque.");
        }

        if (produto.getQuantidadeEstoque() <= 0 || produto.getQuantidadeEstoque() < quantidade) {
            throw new IllegalStateException("Estoque insuficiente ou indisponível para saída.");
        }

        produto.setQuantidadeEstoque(produto.getQuantidadeEstoque() - quantidade);
        produtoRepository.save(produto);
    }
}