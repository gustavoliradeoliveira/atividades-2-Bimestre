package br.com.mvc.integracao;

import static org.junit.jupiter.api.Assertions.*;
import com.sun.net.httpserver.HttpServer;
import java.math.BigDecimal;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicReference;
import org.junit.jupiter.api.Test;
import org.springframework.web.client.RestClient;

class HubFaturamentoClientTest {
    @Test
    void enviaContratoDaAula7ELerIdRetornado() throws Exception {
        var server = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
        var corpoRecebido = new AtomicReference<String>();
        var metodoRecebido = new AtomicReference<String>();
        String idFatura = UUID.randomUUID().toString();
        server.createContext("/fatura", exchange -> {
            try {
                metodoRecebido.set(exchange.getRequestMethod());
                corpoRecebido.set(new String(exchange.getRequestBody().readAllBytes(), StandardCharsets.UTF_8));
                byte[] resposta = ("{\"faturaId\":\"" + idFatura + "\"}").getBytes(StandardCharsets.UTF_8);
                exchange.getResponseHeaders().set("Content-Type", "application/json");
                exchange.sendResponseHeaders(201, resposta.length);
                exchange.getResponseBody().write(resposta);
            } finally {
                exchange.close();
            }
        });
        server.start();
        try {
            var client = new HubFaturamentoClient(RestClient.builder()
                    .baseUrl("http://127.0.0.1:" + server.getAddress().getPort())
                    .build());
            assertEquals(idFatura, client.solicitarFatura(42L, new BigDecimal("120.00"), "a@b.com"));
            assertEquals("POST", metodoRecebido.get());
            assertTrue(corpoRecebido.get().contains("\"pedidoId\":42"));
            assertTrue(corpoRecebido.get().contains("\"valor\":120.00"));
            assertTrue(corpoRecebido.get().contains("\"emailCliente\":\"a@b.com\""));
        } finally {
            server.stop(0);
        }
    }
}
