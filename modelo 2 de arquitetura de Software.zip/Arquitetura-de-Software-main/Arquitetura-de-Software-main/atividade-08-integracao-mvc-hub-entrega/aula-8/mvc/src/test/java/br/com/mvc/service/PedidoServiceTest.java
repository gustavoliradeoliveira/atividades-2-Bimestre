package br.com.mvc.service;

import br.com.mvc.integracao.HubFaturamentoClient;
import br.com.mvc.integracao.IntegracaoHubException;
import br.com.mvc.model.Pedido;
import br.com.mvc.model.Produto;
import br.com.mvc.model.StatusPedido;
import br.com.mvc.repository.PedidoRepository;
import br.com.mvc.repository.ProdutoRepository;
import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.util.Optional;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

class PedidoServiceTest {
    private PedidoRepository pedidos;
    private ProdutoRepository produtos;
    private HubFaturamentoClient hub;
    private PedidoService service;
    private Pedido pedido;
    private Produto produto;

    @BeforeEach
    void preparar() throws Exception {
        pedidos = mock(PedidoRepository.class);
        produtos = mock(ProdutoRepository.class);
        hub = mock(HubFaturamentoClient.class);
        service = new PedidoService(pedidos, produtos, hub);
        produto = new Produto("Teclado", "Mecânico");
        produto.entrarEstoque(6);
        pedido = new Pedido(produto, 2, new BigDecimal("120.00"), "cliente@teste.com");
        Field campoId = Pedido.class.getDeclaredField("id");
        campoId.setAccessible(true);
        campoId.set(pedido, 42L);
        when(pedidos.findById(42L)).thenReturn(Optional.of(pedido));
    }

    @Test
    void fechaPedidoChamaHubSalvaIdEBaixaEstoque() {
        String uuid = UUID.randomUUID().toString();
        when(hub.solicitarFatura(42L, new BigDecimal("120.00"), "cliente@teste.com")).thenReturn(uuid);
        var resultado = service.fechar(42L);
        assertTrue(resultado.sucesso());
        assertEquals(uuid, pedido.getFaturaId());
        assertEquals(StatusPedido.FATURAMENTO_SOLICITADO, pedido.getStatus());
        assertEquals(4, produto.getQuantidadeEstoque());
        verify(pedidos).save(pedido);
        verify(produtos).save(produto);
    }

    @Test
    void timeoutNaoBaixaEstoqueNemReenviaSemConciliacao() {
        when(hub.solicitarFatura(anyLong(), any(), anyString()))
                .thenThrow(new IntegracaoHubException("timeout"));
        var resultado = service.fechar(42L);
        assertFalse(resultado.sucesso());
        assertEquals(StatusPedido.CONFIRMACAO_PENDENTE, pedido.getStatus());
        assertEquals(6, produto.getQuantidadeEstoque());
        verify(produtos, never()).save(any());
        var segundaTentativa = service.fechar(42L);
        assertFalse(segundaTentativa.sucesso());
        verify(hub, times(1)).solicitarFatura(anyLong(), any(), anyString());
    }

    @Test
    void fecharNovamenteNaoGeraOutraFatura() {
        String uuid = UUID.randomUUID().toString();
        when(hub.solicitarFatura(anyLong(), any(), anyString())).thenReturn(uuid);
        service.fechar(42L);
        service.fechar(42L);
        verify(hub, times(1)).solicitarFatura(anyLong(), any(), anyString());
        assertEquals(4, produto.getQuantidadeEstoque());
    }
}
