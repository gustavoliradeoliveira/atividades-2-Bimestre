package br.com.mvc.model;

import br.com.mvc.service.RegraNegocioException;
import java.math.BigDecimal;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class PedidoTest {
    private Produto produtoComEstoque(int quantidade) {
        Produto produto = new Produto("Mouse", "Wireless");
        if (quantidade > 0) produto.entrarEstoque(quantidade);
        return produto;
    }

    @Test
    void pedidoAbertoComProdutoEDadosValidos() {
        Pedido pedido = new Pedido(produtoComEstoque(5), 2, new BigDecimal("99.90"), "cliente@teste.com");
        assertEquals(StatusPedido.ABERTO, pedido.getStatus());
        assertNull(pedido.getFaturaId());
    }

    @Test
    void naoPermiteVendaAcimaDoEstoque() {
        assertThrows(RegraNegocioException.class,
                () -> new Pedido(produtoComEstoque(1), 2, new BigDecimal("10.00"), "a@b.com"));
    }

    @Test
    void registraUuidRecebidoDoHub() {
        Pedido pedido = new Pedido(produtoComEstoque(3), 1, new BigDecimal("15.00"), "a@b.com");
        String idFatura = UUID.randomUUID().toString();
        pedido.registrarFatura(idFatura);
        assertEquals(idFatura, pedido.getFaturaId());
        assertEquals(StatusPedido.FATURAMENTO_SOLICITADO, pedido.getStatus());
        assertThrows(RegraNegocioException.class, () -> pedido.registrarFatura(UUID.randomUUID().toString()));
    }

    @Test
    void erroDeComunicacaoDeixaStatusPendenteSemId() {
        Pedido pedido = new Pedido(produtoComEstoque(2), 1, new BigDecimal("15.00"), "a@b.com");
        pedido.marcarConfirmacaoPendente("timeout");
        assertEquals(StatusPedido.CONFIRMACAO_PENDENTE, pedido.getStatus());
        assertNull(pedido.getFaturaId());
    }
}
