package br.com.mvc.model;

/** Situação da solicitação de faturamento, não do processamento final da fatura no hub. */
public enum StatusPedido {
    ABERTO("ABERTO"),
    FATURAMENTO_SOLICITADO("FATURAMENTO SOLICITADO"),
    CONFIRMACAO_PENDENTE("CONFIRMAÇÃO PENDENTE");

    private final String rotulo;
    StatusPedido(String rotulo) { this.rotulo = rotulo; }
    public String getRotulo() { return rotulo; }
}
