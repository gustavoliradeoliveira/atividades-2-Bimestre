package br.com.mvc.model;

import br.com.mvc.service.RegraNegocioException;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Version;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(name = "pedidos")
public class Pedido {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(optional = false, fetch = FetchType.EAGER)
    @JoinColumn(name = "produto_id", nullable = false)
    private Produto produto;

    @Column(nullable = false)
    private int quantidade;

    @Column(nullable = false, precision = 14, scale = 2)
    private BigDecimal valor;

    @Column(name = "email_cliente", nullable = false, length = 254)
    private String emailCliente;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 30)
    private StatusPedido status;

    @Column(name = "fatura_id", length = 36, unique = true)
    private String faturaId;

    @Column(name = "detalhe_integracao", length = 500)
    private String detalheIntegracao;

    @Column(name = "criado_em", nullable = false)
    private LocalDateTime criadoEm;

    @Version
    private Long versao;

    protected Pedido() { }

    public Pedido(Produto produto, int quantidade, BigDecimal valor, String emailCliente) {
        if (produto == null) throw new RegraNegocioException("Selecione um produto.");
        if (quantidade <= 0) throw new RegraNegocioException("A quantidade deve ser maior que zero.");
        if (valor == null || valor.compareTo(BigDecimal.ZERO) <= 0 || valor.scale() > 2) {
            throw new RegraNegocioException("Informe um valor positivo com até duas casas decimais.");
        }
        if (emailCliente == null || !emailCliente.matches("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$")
                || emailCliente.length() > 254) {
            throw new RegraNegocioException("Informe um e-mail válido para o cliente.");
        }
        this.produto = produto;
        this.quantidade = quantidade;
        this.valor = valor;
        this.emailCliente = emailCliente.trim();
        this.status = StatusPedido.ABERTO;
        this.criadoEm = LocalDateTime.now();
        validarEstoque();
    }

    /** Revalida no fechamento porque o estoque pode mudar após criar o pedido. */
    public void validarEstoque() {
        if (produto.isDescontinuado()) {
            throw new RegraNegocioException("Produto descontinuado não pode ser vendido.");
        }
        if (produto.getQuantidadeEstoque() < quantidade) {
            throw new RegraNegocioException("Estoque insuficiente para fechar este pedido.");
        }
    }

    public void registrarFatura(String idRecebido) {
        if (status != StatusPedido.ABERTO) {
            throw new RegraNegocioException("Este pedido não está aberto para faturamento.");
        }
        try {
            UUID.fromString(idRecebido);
        } catch (RuntimeException ex) {
            throw new RegraNegocioException("O hub devolveu um ID de fatura inválido.");
        }
        this.faturaId = idRecebido;
        this.status = StatusPedido.FATURAMENTO_SOLICITADO;
        this.detalheIntegracao = null;
    }

    /** Falhas de comunicação deixam resultado indeterminado; não fazer retry cego. */
    public void marcarConfirmacaoPendente(String motivo) {
        if (status != StatusPedido.ABERTO) {
            throw new RegraNegocioException("Não é possível alterar a situação deste pedido.");
        }
        this.status = StatusPedido.CONFIRMACAO_PENDENTE;
        this.detalheIntegracao = motivo == null ? "Sem resposta do hub" : motivo.substring(0, Math.min(500, motivo.length()));
    }

    public Long getId() { return id; }
    public Produto getProduto() { return produto; }
    public int getQuantidade() { return quantidade; }
    public BigDecimal getValor() { return valor; }
    public String getEmailCliente() { return emailCliente; }
    public StatusPedido getStatus() { return status; }
    public String getFaturaId() { return faturaId; }
    public String getDetalheIntegracao() { return detalheIntegracao; }
    public LocalDateTime getCriadoEm() { return criadoEm; }
}
