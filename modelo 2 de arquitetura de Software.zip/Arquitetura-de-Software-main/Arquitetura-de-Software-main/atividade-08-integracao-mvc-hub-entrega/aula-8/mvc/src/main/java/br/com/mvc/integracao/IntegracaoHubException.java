package br.com.mvc.integracao;

public class IntegracaoHubException extends RuntimeException {
    public IntegracaoHubException(String mensagem, Throwable causa) { super(mensagem, causa); }
    public IntegracaoHubException(String mensagem) { super(mensagem); }
}
