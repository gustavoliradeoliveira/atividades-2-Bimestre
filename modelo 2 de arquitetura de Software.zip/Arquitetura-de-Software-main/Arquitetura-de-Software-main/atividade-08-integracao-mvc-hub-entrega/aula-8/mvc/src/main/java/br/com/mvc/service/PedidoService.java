package br.com.mvc.service;

import br.com.mvc.integracao.HubFaturamentoClient;
import br.com.mvc.integracao.IntegracaoHubException;
import br.com.mvc.model.Pedido;
import br.com.mvc.model.Produto;
import br.com.mvc.model.StatusPedido;
import br.com.mvc.repository.PedidoRepository;
import br.com.mvc.repository.ProdutoRepository;
import java.math.BigDecimal;
import java.util.List;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Demonstração acadêmica: chama o hub pelo contrato REST da Aula 7 e guarda o ID.
 * NÃO usa retry automático: uma resposta perdida pode esconder uma fatura já criada.
 * Para produção, usar idempotência, outbox/saga e reconciliação explícita.
 */
@Service
public class PedidoService {
    private final PedidoRepository pedidos;
    private final ProdutoRepository produtos;
    private final HubFaturamentoClient hub;

    public PedidoService(PedidoRepository pedidos, ProdutoRepository produtos, HubFaturamentoClient hub) {
        this.pedidos = pedidos;
        this.produtos = produtos;
        this.hub = hub;
    }

    @Transactional(readOnly = true)
    public List<Pedido> listar() { return pedidos.findAll(); }

    @Transactional(readOnly = true)
    public Pedido buscar(Long id) {
        return pedidos.findById(id).orElseThrow(() -> new PedidoNaoEncontradoException(id));
    }

    @Transactional
    public Pedido criar(Long produtoId, int quantidade, BigDecimal valor, String emailCliente) {
        Produto produto = produtos.findById(produtoId)
                .orElseThrow(() -> new ProdutoNaoEncontradoException(produtoId));
        return pedidos.save(new Pedido(produto, quantidade, valor, emailCliente));
    }

    @Transactional
    public ResultadoFechamento fechar(Long id) {
        Pedido pedido = buscar(id);
        if (pedido.getStatus() == StatusPedido.FATURAMENTO_SOLICITADO) {
            return new ResultadoFechamento(true,
                    "Pedido já faturado no hub. ID armazenado: " + pedido.getFaturaId());
        }
        if (pedido.getStatus() == StatusPedido.CONFIRMACAO_PENDENTE) {
            return new ResultadoFechamento(false,
                    "O retorno do hub ficou incerto. Verifique o hub antes de reenviar; retry pode gerar duplicidade.");
        }

        pedido.validarEstoque();
        try {
            // Contrato exato da Aula 7: POST /fatura {pedidoId, valor, emailCliente}
            String faturaId = hub.solicitarFatura(pedido.getId(), pedido.getValor(), pedido.getEmailCliente());
            // Apenas após confirmação do POST: baixa estoque local e salva ID na mesma transação MVC.
            pedido.getProduto().sairEstoque(pedido.getQuantidade());
            produtos.save(pedido.getProduto());
            pedido.registrarFatura(faturaId);
            pedidos.save(pedido);
            return new ResultadoFechamento(true,
                    "Pedido fechado. ID de fatura recebido e salvo: " + faturaId);
        } catch (IntegracaoHubException ex) {
            // Não houve confirmação do resultado: evita reenviar automaticamente.
            pedido.marcarConfirmacaoPendente(ex.getMessage());
            pedidos.save(pedido);
            return new ResultadoFechamento(false,
                    "Não foi possível confirmar o faturamento. Pedido mantido sem baixa de estoque. "
                    + "Não reenvie sem conciliar a situação no hub.");
        }
    }

    public record ResultadoFechamento(boolean sucesso, String mensagem) { }
}
