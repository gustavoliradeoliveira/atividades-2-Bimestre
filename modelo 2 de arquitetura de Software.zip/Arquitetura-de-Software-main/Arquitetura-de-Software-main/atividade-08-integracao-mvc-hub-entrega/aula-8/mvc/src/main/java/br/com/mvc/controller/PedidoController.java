package br.com.mvc.controller;

import br.com.mvc.model.Produto;
import br.com.mvc.service.PedidoService;
import br.com.mvc.service.ProdutoService;
import br.com.mvc.service.RegraNegocioException;
import java.math.BigDecimal;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/pedidos")
public class PedidoController {
    private final PedidoService pedidos;
    private final ProdutoService produtos;

    public PedidoController(PedidoService pedidos, ProdutoService produtos) {
        this.pedidos = pedidos;
        this.produtos = produtos;
    }

    @GetMapping
    public String listar(Model model, Authentication usuario) {
        model.addAttribute("pedidos", pedidos.listar());
        model.addAttribute("usuario", usuario.getName());
        return "pedidos";
    }

    @GetMapping("/novo")
    public String novo(Model model) {
        model.addAttribute("produtos", produtos.listar().stream()
                .filter(p -> !p.isDescontinuado() && p.getQuantidadeEstoque() > 0)
                .toList());
        return "pedido-form";
    }

    @PostMapping
    public String criar(@RequestParam Long produtoId,
                        @RequestParam int quantidade,
                        @RequestParam BigDecimal valor,
                        @RequestParam String emailCliente,
                        RedirectAttributes redirect) {
        try {
            var pedido = pedidos.criar(produtoId, quantidade, valor, emailCliente);
            redirect.addFlashAttribute("sucesso", "Pedido #" + pedido.getId() + " criado. Feche-o para solicitar faturamento.");
            return "redirect:/pedidos";
        } catch (RegraNegocioException ex) {
            redirect.addFlashAttribute("erro", ex.getMessage());
            return "redirect:/pedidos/novo";
        }
    }

    @GetMapping("/{id}")
    public String detalhe(@PathVariable Long id, Model model) {
        model.addAttribute("pedido", pedidos.buscar(id));
        return "pedido-detalhe";
    }

    @PostMapping("/{id}/fechar")
    public String fechar(@PathVariable Long id, RedirectAttributes redirect) {
        try {
            var resultado = pedidos.fechar(id);
            redirect.addFlashAttribute(resultado.sucesso() ? "sucesso" : "erro", resultado.mensagem());
        } catch (RegraNegocioException ex) {
            redirect.addFlashAttribute("erro", ex.getMessage());
        }
        return "redirect:/pedidos/" + id;
    }
}
