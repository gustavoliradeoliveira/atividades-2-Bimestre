package br.com.mvc.integracao;

import java.math.BigDecimal;
import java.util.UUID;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestClientException;

/** Adaptador HTTP da aplicação MVC para o contrato da Atividade 7. */
@Component
public class HubFaturamentoClient {
    private final RestClient restClient;

    public HubFaturamentoClient(@Qualifier("hubRestClient") RestClient restClient) {
        this.restClient = restClient;
    }

    public String solicitarFatura(Long pedidoId, BigDecimal valor, String emailCliente) {
        try {
            FaturaPostResponse resposta = restClient.post()
                    .uri("/fatura")
                    .body(new FaturaPostRequest(pedidoId, valor, emailCliente))
                    .retrieve()
                    .body(FaturaPostResponse.class);
            if (resposta == null || resposta.faturaId() == null) {
                throw new IntegracaoHubException("O hub não devolveu o ID da fatura.");
            }
            try {
                return UUID.fromString(resposta.faturaId()).toString();
            } catch (IllegalArgumentException e) {
                throw new IntegracaoHubException("O hub devolveu um ID de fatura inválido.", e);
            }
        } catch (RestClientException e) {
            throw new IntegracaoHubException(
                    "Falha ao chamar o hub de faturamento (HTTP, timeout ou conexão).", e);
        }
    }

    public record FaturaPostRequest(Long pedidoId, BigDecimal valor, String emailCliente) { }
    public record FaturaPostResponse(String faturaId) { }
}
