# Atividade 08 — Análise de dois problemas na integração MVC → hub

## Contexto

Ao fechar o pedido, a aplicação de vendas (Spring MVC) envia `POST /fatura` ao hub hexagonal da Aula 7 com o JSON `pedidoId`, `valor` e `emailCliente`. O hub devolve HTTP `201 Created` com o campo `faturaId`. A aplicação MVC armazena esse ID no pedido. A criação da fatura **não significa que boleto, nota e e-mail terminaram**, porque o processamento do hub usa uma fila simulada.

## Problema 1 — Hub indisponível ou muito lento (timeout)

**O que acontece:** o MVC chama o hub, mas a conexão falha ou o tempo de resposta ultrapassa o limite. O MVC não recebe um ID de fatura confiável. Dependendo do momento da falha, o hub pode não ter criado nada **ou pode ter criado a fatura e perdido a resposta**.

**O que acontece com o pedido:** o pedido não recebe `faturaId`. Nesta implementação, seu estado muda de `ABERTO` para `CONFIRMACAO_PENDENTE`; a baixa local do estoque não é feita, e não ocorre reenvio automático. É necessário reconciliar a situação com os registros ou banco do hub.

**O que o negócio percebe:** o atendente não consegue confirmar o faturamento da venda, há atraso no atendimento e risco de fatura remota existir sem vínculo local. O cliente pode ficar esperando o boleto ou a nota, embora o processamento remoto possa ter começado.

**Solução estudada:** **Timeout combinado com Circuit Breaker**. O timeout limita quanto tempo a aplicação espera. O Circuit Breaker fica **na saída REST do MVC para o hub**, monitorando falhas e interrompendo temporariamente chamadas quando o hub está instável, para evitar sobrecarga e falhas em cascata. Ele permite tentativas controladas de recuperação.

**Justificativa e limite:** essas medidas protegem a disponibilidade da aplicação de vendas, mas **não determinam se o hub criou a fatura**. Para tratar respostas perdidas, também é necessário conciliar os pedidos com as faturas no hub e projetar operações idempotentes antes de permitir retry.

**O que foi codificado:** timeout de conexão de 3 s e leitura de 5 s no `HubRestConfig`; status `CONFIRMACAO_PENDENTE` e bloqueio de reenvio sem conciliação. **Circuit Breaker não foi implementado**, é a solução arquitetural proposta no estudo.

## Problema 2 — Faturamento duplicado por reenvio

**O que acontece:** o hub cria a fatura, mas a resposta `201` se perde. Se o MVC ou usuário fizer novamente `POST /fatura` para o mesmo `pedidoId`, o hub da Aula 7 cria uma nova fatura com outro UUID, pois não há, nele, verificação de duplicidade por pedido.

**O que acontece com o pedido:** sem controle, um pedido pode se relacionar com duas faturas remotas, embora o banco MVC armazene no máximo um `faturaId`. Em um reenvio manual, o vínculo pode ser ambíguo.

**O que o negócio percebe:** risco de cobrança duplicada, boletos e notificações repetidos, custo operacional de cancelamentos e perda de confiança do cliente.

**Solução estudada:** **Idempotência**, implementada **no endpoint de entrada REST do hub de faturamento**. O hub deve receber e persistir uma chave idempotente (por exemplo, identificador único da operação ou `pedidoId` com unicidade no contexto da venda). Ao receber a mesma solicitação novamente, ele **devolve o mesmo `faturaId`**, em vez de criar nova fatura; deve verificar também se os dados da nova tentativa coincidem. Isso permite ao MVC fazer retry com segurança após falhas transitórias.

**Justificativa e limite:** impedir um segundo clique na tela é útil, mas não substitui idempotência no hub, porque um timeout ou uma corrida entre duas requisições pode duplicar uma operação remotamente. O banco de dados do hub precisaria de restrição de unicidade/transação adequada para evitar concorrência.

**O que foi codificado:** o MVC impede reenviar um pedido que já recebeu `faturaId` e bloqueia reenvios automáticos de pedidos com resposta incerta. **A idempotência no hub não foi implementada nesta atividade**, pois o enunciado pede a análise e a chamada REST do lado MVC. É uma melhoria necessária para retries seguros.

## Relação com a teoria da Aula 8

| Situação | Técnica estudada | Onde atua |
|---|---|---|
| Hub travado ou instável | Timeout / Circuit Breaker | Cliente HTTP do MVC, antes e durante a chamada ao hub |
| POST repetido após perda de resposta | Idempotência | REST/serviço e persistência do hub, identificando a mesma operação |

## Conclusão

A aplicação MVC implementa o contrato `POST /fatura`, persiste o identificador devolvido e mantém estado explícito quando não há resposta. Em sistemas distribuídos, **não receber uma resposta não significa que nada aconteceu**; por isso, retries seguros exigem idempotência e possibilidade de reconciliação.
