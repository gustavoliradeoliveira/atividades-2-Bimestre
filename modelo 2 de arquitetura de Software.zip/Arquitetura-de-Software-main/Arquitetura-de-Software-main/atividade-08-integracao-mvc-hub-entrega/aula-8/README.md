# Atividade 08 — Integrando a venda ao hub

Implementação do enunciado do professor: **aplicação MVC faz chamada REST ao hub hexagonal da Aula 7 ao fechar um pedido e salva o `faturaId` recebido**. Contém `analise-problemas.md` com dois problemas de integração, impacto no pedido/negócio e soluções justificadas.

## Estrutura

```text
aula-8/
├── README.md
├── analise-problemas.md
└── mvc/
    ├── pom.xml
    ├── mvnw.cmd
    └── src/
        ├── main/java/br/com/mvc/
        │   ├── controller/PedidoController.java    # Telas MVC
        │   ├── model/Pedido.java, StatusPedido.java # Pedido persistente + status + faturaId
        │   ├── repository/PedidoRepository.java     # Acesso JPA
        │   ├── service/PedidoService.java           # Regras e orquestração
        │   ├── integracao/HubFaturamentoClient.java # POST REST ao hub
        │   └── config/HubRestConfig.java            # URL e timeouts
        └── main/resources/view/                     # Telas de pedidos, detalhe e cadastro
```

A pasta `mvc` deriva do projeto da Aula 6 e mantém o módulo de produtos e estoque. Foi acrescentado o fluxo didático de pedidos/vendas (um produto por pedido, valor total informado manualmente porque o cadastro de produtos da Aula 6 não tinha campo de preço). Esse fluxo mantém a baixa de estoque **apenas depois de receber o `faturaId`**. Na falha de comunicação o saldo não é alterado.

## Pré-requisitos

- Java 21 instalado, `JAVA_HOME` configurado.
- **Hub da Atividade 7** disponível na porta **8081** (`aula-7/hexagonal`).
- Aplicação de vendas MVC da Atividade 8 na porta **8080**.

## Executar (PowerShell no Windows; dois terminais)

**Terminal 1 — hub (pasta `aula-7/hexagonal` da atividade anterior):**

```powershell
.\mvnw.cmd spring-boot:run
```

**Terminal 2 — MVC (pasta `aula-8/mvc`):**

```powershell
.\mvnw.cmd test
.\mvnw.cmd spring-boot:run
```

Abra `http://localhost:8080/pedidos`. Login de demonstração herdado da Aula 6: `admin / admin123` ou `operador / operador123` (**somente ambiente local**).

Se o hub estiver em outro endereço, defina antes de iniciar o MVC:

```powershell
$env:HUB_BASE_URL="http://localhost:8081"
```

## Teste manual passo a passo

1. Acesse `/produtos`; cadastre um produto, entre em `Movimentar` e dê entrada de pelo menos 5 unidades.
2. Acesse `/pedidos` → `Novo pedido`; escolha o produto, quantidade `2`, valor `199.90`, e-mail `cliente@exemplo.com`.
3. Abra o pedido criado e clique em **Fechar pedido e chamar hub**.
4. A tela deve mostrar o estado `FATURAMENTO SOLICITADO`, o UUID em `ID da fatura devolvido` e o estoque reduzido em 2 unidades.
5. No navegador ou terminal, consulte `http://localhost:8081/fatura/<UUID>` para ver `PENDENTE`, `PROCESSANDO` ou `CONCLUIDA`, conforme a fila simulada avança.
6. Clique novamente em fechar pela rota/cliente: a aplicação detecta o pedido já faturado e não chama o hub novamente.
7. Para simular erro: desligue o hub, crie outro pedido e tente fechá-lo. Ele passará a `CONFIRMACAO_PENDENTE`, mantendo estoque e sem ID. **Não reenvie cegamente**: verifique o hub antes.

## Contrato da integração

Aula 7 oferece:

```http
POST http://localhost:8081/fatura
Content-Type: application/json

{"pedidoId": 1, "valor": 199.90, "emailCliente": "cliente@exemplo.com"}
```

Resposta esperada:

```http
HTTP/1.1 201 Created
Content-Type: application/json

{"faturaId": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"}
```

A aplicação armazena `faturaId` em `pedidos.fatura_id` no banco H2 local e **não confunde** aceitação do hub com processamento completo de boleto, nota e e-mail.

## Limitações de demonstração e robustez

- A criação da fatura no hub é assíncrona após o POST; o MVC guarda o UUID, não verifica conclusão do processamento.
- Não há transação distribuída entre o hub e o banco MVC. A chamada HTTP ocorre durante a transação local do MVC, propositalmente simples para a atividade, mas **não adequada a produção**: existe possibilidade de faturamento remoto mesmo que a transação local falhe.
- Sem idempotência do lado do hub, retry cego pode criar faturas duplicadas. Quando houver erro HTTP/timeout, o pedido entra em `CONFIRMACAO_PENDENTE` e o botão de reenvio é bloqueado para evitar esse risco.
- A etapa de conciliação manual ainda não possui tela: deve ser feita verificando registros do hub. Em produção, é necessário endpoint de consulta por `pedidoId`, chave idempotente persistida, timeout, circuit breaker, outbox e/ou saga conforme os casos.
- Autenticação local com usuários de demonstração não é apropriada para exposição pública.

## Arquivos para entregar no GitHub

Copie **somente** `aula-8/` para a raiz do repositório, sem sobrescrever as pastas `aula-6` ou `aula-7`:

```powershell
git add aula-8
git commit -m "Atividade 08 - Integracao MVC com hub hexagonal"
git push
```
