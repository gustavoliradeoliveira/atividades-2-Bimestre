# Aula 06 — Atividade: Módulo de Estoque

**Disciplina:** Arquitetura de Software  
**Entrega:** projeto MVC funcional + diagramas Mermaid, conforme o slide `atividade-6.pptx`.

## O que foi implementado

- Cadastro de produtos com estoque inicial **0** e status **INDISPONIVEL**.
- Listagem, edição de nome e descrição e tela para movimentar estoque.
- Entrada de quantidade positiva. Ao sair de zero, status vira **DISPONIVEL**.
- Saída de quantidade positiva, sem permitir saldo negativo. Ao zerar, status vira **INDISPONIVEL**.
- Produto **DESCONTINUADO** não permite entrada nem saída, inclusive por acesso direto ao endpoint.
- Apenas o perfil **ADMIN** consegue descontinuar; a restrição é aplicada no servidor pelo Spring Security e por `@PreAuthorize` no serviço.
- Persistência H2 local com Spring Data JPA. Status e saldo são controlados pela entidade, não diretamente pela interface.
- Testes unitários das principais regras de estoque.

## Organização

```text
aula-6/
├── README.md
├── diagramas/
│   ├── sequencia-entrada.mermaid
│   ├── sequencia-saida.mermaid
│   ├── atividades-saida.mermaid
│   └── estados-produto.mermaid
└── mvc/
    ├── pom.xml
    └── src/main/
        ├── java/br/com/mvc/
        │   ├── config/SegurancaConfig.java
        │   ├── controller/ProdutoController.java
        │   ├── controller/EstoqueController.java
        │   ├── model/Produto.java
        │   ├── model/StatusProduto.java
        │   ├── repository/ProdutoRepository.java
        │   └── service/ProdutoService.java
        └── resources/view/ (... telas Thymeleaf)
```

O MVC foi iniciado a partir do `mvc.zip` disponibilizado junto aos materiais da disciplina. A implementação foi adicionada sem os arquivos compilados da pasta `target`.

## Como rodar no Windows (VS Code / terminal)

1. Tenha **JDK 25 (LTS)** instalado e configurado (`java -version`).
2. Abra o terminal **dentro de `aula-6/mvc`** (pasta que tem `pom.xml`).
3. Execute `./mvnw.cmd spring-boot:run` no PowerShell ou `mvn spring-boot:run` se já tiver Maven instalado.
4. Abra **http://localhost:8080**. O sistema pede login antes de acessar os produtos.
5. Para rodar os testes, use `./mvnw.cmd test`.

> Na primeira execução o Maven precisa acessar a internet para baixar as dependências. O banco H2 é criado no diretório `mvc/data/` em que o comando é executado, e seus dados sobrevivem aos reinícios.

### Contas demonstrativas (somente para a atividade)

| Usuário | Senha | Perfil | Pode descontinuar? |
|---|---|---|---|
| `admin` | `admin123` | ADMIN | Sim |
| `operador` | `operador123` | OPERADOR | Não |

**Importante:** são credenciais didáticas fixas, **não** adequadas a produção. Em um sistema real, contas e senhas seriam cadastradas de forma segura e configuradas fora do código.

## Roteiro de verificação manual

1. Login como `operador` e cadastro de **Mouse**. Verificar `0 / INDISPONIVEL`.
2. Entrar **5** unidades. Verificar `5 / DISPONIVEL`.
3. Sair **2** unidades. Verificar `3 / DISPONIVEL`.
4. Tentar sair **4** unidades. Verificar erro e saldo inalterado.
5. Sair **3** unidades. Verificar `0 / INDISPONIVEL`.
6. Login como `admin` e descontinuar o Mouse. Verificar `DESCONTINUADO` e ações de estoque bloqueadas.
7. Conferir que `operador` não consegue descontinuar por POST direto: deve receber HTTP 403 (com CSRF válido).
8. Conferir os arquivos `.mermaid` na pasta `diagramas/` em um visualizador Mermaid.

## Por que essa estrutura segue o MVC?

- **Model:** `Produto` guarda dados, estados e invariantes de estoque.
- **View:** páginas HTML com Thymeleaf exibem o catálogo, formulário e movimentação.
- **Controller:** recebe requisições HTTP, chama o serviço e seleciona/redireciona a view.
- **Service:** organiza as operações (transações) e impede descontinuar sem `ADMIN`.
- **Repository:** abstrai a gravação e a leitura do H2 via JPA.

## Observações

- O enunciado pede status com nomes em português acentuado. No código Java, os identificadores do `enum` foram escritos `DISPONIVEL`, `INDISPONIVEL`, `DESCONTINUADO` **sem acentos**, por convenção; correspondem aos estados **DISPONÍVEL**, **INDISPONÍVEL** e **DESCONTINUADO**. A tela mostra os rótulos acentuados.
- Depois de descontinuar, o saldo existente é mantido para consulta, mas não pode ser alterado por entradas/saídas.
- Há controle de versão otimista (`@Version`) na entidade para detectar gravações concorrentes conflitantes.
- O projeto foi preparado como entrega acadêmica. Teste a inicialização e as telas na sua máquina antes de enviar ao GitHub.
