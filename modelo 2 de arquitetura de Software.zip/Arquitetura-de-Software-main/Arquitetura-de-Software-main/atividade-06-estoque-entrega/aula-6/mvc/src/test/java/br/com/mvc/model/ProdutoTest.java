package br.com.mvc.model;

import br.com.mvc.service.RegraNegocioException;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ProdutoTest {

    @Test
    void novoProdutoComecaIndisponivelComEstoqueZero() {
        Produto p = new Produto("Teclado", "USB");
        assertEquals(0, p.getQuantidadeEstoque());
        assertEquals(StatusProduto.INDISPONIVEL, p.getStatus());
    }

    @Test
    void primeiraEntradaDisponibilizaProduto() {
        Produto p = new Produto("Teclado", "USB");
        p.entrarEstoque(3);
        assertEquals(3, p.getQuantidadeEstoque());
        assertEquals(StatusProduto.DISPONIVEL, p.getStatus());
    }

    @Test
    void zerarEstoqueTornaIndisponivel() {
        Produto p = new Produto("Teclado", "USB");
        p.entrarEstoque(3);
        p.sairEstoque(3);
        assertEquals(0, p.getQuantidadeEstoque());
        assertEquals(StatusProduto.INDISPONIVEL, p.getStatus());
    }

    @Test
    void retiradaParcialMantemDisponivel() {
        Produto p = new Produto("Teclado", "USB");
        p.entrarEstoque(5);
        p.sairEstoque(2);
        assertEquals(3, p.getQuantidadeEstoque());
        assertEquals(StatusProduto.DISPONIVEL, p.getStatus());
    }

    @Test
    void naoPermiteSaidaSemEstoque() {
        Produto p = new Produto("Teclado", "USB");
        assertThrows(RegraNegocioException.class, () -> p.sairEstoque(1));
        assertEquals(0, p.getQuantidadeEstoque());
    }

    @Test
    void naoPermiteSaidaMaiorQueSaldo() {
        Produto p = new Produto("Teclado", "USB");
        p.entrarEstoque(2);
        assertThrows(RegraNegocioException.class, () -> p.sairEstoque(3));
        assertEquals(2, p.getQuantidadeEstoque());
    }

    @Test
    void naoPermiteQuantidadesZeroOuNegativas() {
        Produto p = new Produto("Teclado", "USB");
        assertThrows(RegraNegocioException.class, () -> p.entrarEstoque(0));
        assertThrows(RegraNegocioException.class, () -> p.sairEstoque(-1));
    }

    @Test
    void descontinuadoNaoPodeReceberOuSairEstoque() {
        Produto p = new Produto("Teclado", "USB");
        p.entrarEstoque(2);
        p.descontinuar();
        assertEquals(StatusProduto.DESCONTINUADO, p.getStatus());
        assertThrows(RegraNegocioException.class, () -> p.entrarEstoque(1));
        assertThrows(RegraNegocioException.class, () -> p.sairEstoque(1));
        assertEquals(2, p.getQuantidadeEstoque());
    }

    @Test
    void edicaoNaoAlteraStatusOuSaldo() {
        Produto p = new Produto("Antigo", "");
        p.entrarEstoque(4);
        p.atualizarDados("Novo", "atualizado");
        assertEquals(4, p.getQuantidadeEstoque());
        assertEquals(StatusProduto.DISPONIVEL, p.getStatus());
    }
}
