package br.com.mvc.controller;

import br.com.mvc.service.ProdutoService;
import br.com.mvc.service.RegraNegocioException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/estoque")
public class EstoqueController {
    private final ProdutoService service;

    public EstoqueController(ProdutoService service) {
        this.service = service;
    }

    @GetMapping("/{id}")
    public String tela(@PathVariable Long id, Model model) {
        model.addAttribute("produto", service.buscar(id));
        return "estoque";
    }

    @PostMapping("/{id}/entrada")
    public String entrada(@PathVariable Long id, @RequestParam int quantidade,
                          RedirectAttributes redirect) {
        try {
            service.registrarEntrada(id, quantidade);
            redirect.addFlashAttribute("sucesso", "Entrada registrada com sucesso.");
        } catch (RegraNegocioException ex) {
            redirect.addFlashAttribute("erro", ex.getMessage());
        }
        return "redirect:/estoque/" + id;
    }

    @PostMapping("/{id}/saida")
    public String saida(@PathVariable Long id, @RequestParam int quantidade,
                        RedirectAttributes redirect) {
        try {
            service.registrarSaida(id, quantidade);
            redirect.addFlashAttribute("sucesso", "Saída registrada com sucesso.");
        } catch (RegraNegocioException ex) {
            redirect.addFlashAttribute("erro", ex.getMessage());
        }
        return "redirect:/estoque/" + id;
    }
}
