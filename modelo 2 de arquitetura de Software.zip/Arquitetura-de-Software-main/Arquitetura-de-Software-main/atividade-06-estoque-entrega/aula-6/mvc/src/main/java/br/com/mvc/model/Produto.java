package br.com.mvc.model;

import br.com.mvc.service.RegraNegocioException;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Version;

@Entity
@Table(name = "produtos")
public class Produto {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 120)
    private String nome;

    @Column(length = 500)
    private String descricao;

    @Column(nullable = false)
    private int quantidadeEstoque;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private StatusProduto status;

    @Version
    private Long versao;

    protected Produto() { }

    public Produto(String nome, String descricao) {
        atualizarDados(nome, descricao);
        this.quantidadeEstoque = 0;
        this.status = StatusProduto.INDISPONIVEL;
    }

    public void atualizarDados(String nome, String descricao) {
        if (nome == null || nome.isBlank()) {
            throw new RegraNegocioException("Informe o nome do produto.");
        }
        if (nome.trim().length() > 120) {
            throw new RegraNegocioException("O nome pode ter no máximo 120 caracteres.");
        }
        if (descricao != null && descricao.length() > 500) {
            throw new RegraNegocioException("A descrição pode ter no máximo 500 caracteres.");
        }
        this.nome = nome.trim();
        this.descricao = descricao == null ? "" : descricao.trim();
    }

    public void entrarEstoque(int quantidade) {
        exigirAtivo();
        validarQuantidade(quantidade);
        if (quantidade > Integer.MAX_VALUE - quantidadeEstoque) {
            throw new RegraNegocioException("Quantidade ultrapassa o limite de estoque.");
        }
        quantidadeEstoque += quantidade;
        atualizarStatusPeloSaldo();
    }

    public void sairEstoque(int quantidade) {
        exigirAtivo();
        validarQuantidade(quantidade);
        if (quantidade > quantidadeEstoque) {
            throw new RegraNegocioException("Estoque insuficiente para esta saída.");
        }
        quantidadeEstoque -= quantidade;
        atualizarStatusPeloSaldo();
    }

    public void descontinuar() {
        if (status == StatusProduto.DESCONTINUADO) {
            throw new RegraNegocioException("O produto já está descontinuado.");
        }
        status = StatusProduto.DESCONTINUADO;
    }

    private void exigirAtivo() {
        if (status == StatusProduto.DESCONTINUADO) {
            throw new RegraNegocioException("Produto descontinuado não pode movimentar estoque.");
        }
    }

    private static void validarQuantidade(int quantidade) {
        if (quantidade <= 0) {
            throw new RegraNegocioException("A quantidade deve ser maior que zero.");
        }
    }

    private void atualizarStatusPeloSaldo() {
        status = quantidadeEstoque == 0
                ? StatusProduto.INDISPONIVEL
                : StatusProduto.DISPONIVEL;
    }

    public boolean isDescontinuado() {
        return status == StatusProduto.DESCONTINUADO;
    }

    public Long getId() { return id; }
    public String getNome() { return nome; }
    public String getDescricao() { return descricao; }
    public int getQuantidadeEstoque() { return quantidadeEstoque; }
    public StatusProduto getStatus() { return status; }
    public Long getVersao() { return versao; }
}
