package br.com.mvc.model;

public enum StatusProduto {
    DISPONIVEL("DISPONÍVEL"),
    INDISPONIVEL("INDISPONÍVEL"),
    DESCONTINUADO("DESCONTINUADO");

    private final String rotulo;

    StatusProduto(String rotulo) {
        this.rotulo = rotulo;
    }

    public String getRotulo() {
        return rotulo;
    }
}
