package br.com.mvc.controller;

import br.com.mvc.model.Produto;
import br.com.mvc.service.ProdutoService;
import br.com.mvc.service.RegraNegocioException;
import java.util.List;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/produtos")
public class ProdutoController {
    private final ProdutoService service;

    public ProdutoController(ProdutoService service) {
        this.service = service;
    }

    @GetMapping
    public String listar(Model model, Authentication authentication) {
        List<Produto> produtos = service.listar();
        model.addAttribute("produtos", produtos);
        model.addAttribute("isAdmin", authentication.getAuthorities().stream()
                .anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN")));
        model.addAttribute("usuario", authentication.getName());
        return "produtos";
    }

    @GetMapping("/novo")
    public String novo(Model model) {
        model.addAttribute("titulo", "Cadastrar produto");
        model.addAttribute("destino", "/produtos");
        model.addAttribute("nome", "");
        model.addAttribute("descricao", "");
        return "produto-form";
    }

    @PostMapping
    public String criar(@RequestParam String nome,
                        @RequestParam(required = false) String descricao,
                        RedirectAttributes redirect) {
        try {
            service.criar(nome, descricao);
            redirect.addFlashAttribute("sucesso", "Produto cadastrado com estoque zero e status INDISPONÍVEL.");
            return "redirect:/produtos";
        } catch (RegraNegocioException ex) {
            redirect.addFlashAttribute("erro", ex.getMessage());
            return "redirect:/produtos/novo";
        }
    }

    @GetMapping("/{id}/editar")
    public String editarForm(@PathVariable Long id, Model model) {
        Produto produto = service.buscar(id);
        model.addAttribute("titulo", "Editar produto");
        model.addAttribute("destino", "/produtos/" + id + "/editar");
        model.addAttribute("nome", produto.getNome());
        model.addAttribute("descricao", produto.getDescricao());
        return "produto-form";
    }

    @PostMapping("/{id}/editar")
    public String editar(@PathVariable Long id, @RequestParam String nome,
                         @RequestParam(required = false) String descricao,
                         RedirectAttributes redirect) {
        try {
            service.editar(id, nome, descricao);
            redirect.addFlashAttribute("sucesso", "Dados do produto atualizados.");
        } catch (RegraNegocioException ex) {
            redirect.addFlashAttribute("erro", ex.getMessage());
        }
        return "redirect:/produtos";
    }

    @PostMapping("/{id}/descontinuar")
    public String descontinuar(@PathVariable Long id, RedirectAttributes redirect) {
        try {
            service.descontinuar(id);
            redirect.addFlashAttribute("sucesso", "Produto descontinuado.");
        } catch (RegraNegocioException ex) {
            redirect.addFlashAttribute("erro", ex.getMessage());
        }
        return "redirect:/produtos";
    }
}
