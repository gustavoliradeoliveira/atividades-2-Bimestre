package br.com.mvc.service;

import br.com.mvc.model.Produto;
import br.com.mvc.repository.ProdutoRepository;
import java.util.List;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class ProdutoService {
    private final ProdutoRepository repository;

    public ProdutoService(ProdutoRepository repository) {
        this.repository = repository;
    }

    @Transactional(readOnly = true)
    public List<Produto> listar() {
        return repository.findAll();
    }

    @Transactional(readOnly = true)
    public Produto buscar(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ProdutoNaoEncontradoException(id));
    }

    @Transactional
    public Produto criar(String nome, String descricao) {
        return repository.save(new Produto(nome, descricao));
    }

    @Transactional
    public void editar(Long id, String nome, String descricao) {
        Produto produto = buscar(id);
        produto.atualizarDados(nome, descricao);
        repository.save(produto);
    }

    @Transactional
    public void registrarEntrada(Long id, int quantidade) {
        Produto produto = buscar(id);
        produto.entrarEstoque(quantidade);
        repository.save(produto);
    }

    @Transactional
    public void registrarSaida(Long id, int quantidade) {
        Produto produto = buscar(id);
        produto.sairEstoque(quantidade);
        repository.save(produto);
    }

    // Dupla proteção: a rota e o serviço exigem o papel ADMIN.
    @PreAuthorize("hasRole('ADMIN')")
    @Transactional
    public void descontinuar(Long id) {
        Produto produto = buscar(id);
        produto.descontinuar();
        repository.save(produto);
    }
}
