# Atividade 07 — Faturando um pedido no hub de integrações

Implementação baseada no projeto `hexagonal.zip` fornecido pelo professor, usando **Java 21, Spring Boot, REST, JPA e H2**. As integrações por fila, SOAP e SMTP são **simuladas**, conforme a observação do enunciado.

## Requisitos implementados

| Requisito | Implementação | Como verificar |
| --- | --- | --- |
| RF01 — criar e persistir fatura, retornando ID à camada REST | `FaturaServiceImp`, `FaturaRepositoryImp`, `FaturaController` | `POST /fatura` retorna HTTP 201 e `faturaId` |
| RF02 — emitir boleto por fila e gravar código de barras | `BoletoMessaging` + `FilaBoletoSimuladaAdapter` + `ProcessarBoletoService` | `GET /fatura/{id}` mostra `codigoBarras` com 44 dígitos |
| RF03 — emitir nota por SOAP e gravar chave de 44 dígitos | `NotaFiscalSoap` + `NotaFiscalSoapSimuladoAdapter` | `GET /fatura/{id}` mostra `chaveAcessoNota` com 44 dígitos |
| RF04 — notificar por SMTP e gravar hash do conteúdo | `EmailSmtp` + `EmailSmtpSimuladoAdapter` | `GET /fatura/{id}` mostra `hashEmail` (SHA-256 hexadecimal) |

## Estrutura principal

```text
hexagonal/
├── src/main/java/br/com/hexagonal/
│   ├── domain/
│   │   ├── entities/                         # Fatura, StatusFatura
│   │   └── ports/
│   │       ├── in/                           # Portas: faturar e receber boleto
│   │       └── out/                          # Portas: persistência, fila, SOAP, SMTP
│   ├── application/                          # Orquestração dos casos de uso
│   └── infra/adapters/
│       ├── in/rest/                          # Controller + DTOs
│       └── out/                              # JPA/H2, fila, SOAP, SMTP simulados
├── src/test/java/                            # Testes de domínio e integração
├── pom.xml
├── mvnw.cmd                                 # Maven Wrapper para Windows
└── src/main/resources/application.properties
```

## Como executar no Windows (PowerShell, VS Code)

**Pré-requisito:** Java JDK 21 instalado (`java -version` e `javac -version`). O Maven Wrapper cuida do Maven.

Abra o terminal na pasta `aula-7/hexagonal` e rode:

```powershell
.\mvnw.cmd test
.\mvnw.cmd spring-boot:run
```

A API inicia em **http://localhost:8081**. Não é uma aplicação com tela HTML: é uma API REST.

### 1. Criar uma fatura (HTTP POST)

Execute em um **outro** terminal PowerShell:

```powershell
$corpo = @{
  pedidoId = 1001
  valor = 199.90
  emailCliente = "cliente@exemplo.com"
} | ConvertTo-Json

$resposta = Invoke-RestMethod -Uri "http://localhost:8081/fatura" `
  -Method Post -ContentType "application/json" -Body $corpo

$resposta
```

Resposta esperada (o UUID muda a cada execução):

```json
{"faturaId":"f8b64816-2b74-45c1-96ae-d67c0ad0022f"}
```

### 2. Consultar a fatura (HTTP GET)

Ainda no PowerShell:

```powershell
Start-Sleep -Seconds 2
Invoke-RestMethod -Uri "http://localhost:8081/fatura/$($resposta.faturaId)" | Format-List
```

Campos esperados após o processamento: `status = CONCLUIDA`, `codigoBarras` com **44 dígitos**, `chaveAcessoNota` com **44 dígitos**, e `hashEmail` com **64 caracteres hexadecimais**.

A resposta inicial ao POST acontece **antes** da emissão dos documentos. A consulta pode mostrar `PENDENTE` ou `PROCESSANDO` por um curto período; consulte novamente.

### 3. Visualizar o banco de dados (opcional)

H2 Console: http://localhost:8081/h2-console

- JDBC URL: `jdbc:h2:file:./faturas`
- User Name: `sa`
- Password: *vazio*
- SQL: `SELECT * FROM FATURA;`

Os arquivos de dados locais são criados como `hexagonal/faturas.mv.db` e são ignorados pelo Git.

## O que a simulação significa

- **Fila:** `ConcurrentLinkedQueue` em memória + consumidor agendado com `@Scheduled`; nenhum RabbitMQ externo é necessário.
- **Boleto:** código numérico de 44 dígitos **fictício**; não serve para pagamento real.
- **SOAP:** adaptador monta um envelope XML como exemplo e gera **chave fictícia** de 44 dígitos; não chama a SEFAZ.
- **SMTP:** adaptador registra no log a mensagem e calcula seu hash **SHA-256**; não envia e-mail real.
- **Persistência:** H2 em arquivo com JPA; os resultados ficam gravados mesmo ao reiniciar a API.

**Limitação proposital:** a fila em memória não é durável. Se a aplicação parar após salvar a fatura e antes de processar a mensagem, a solicitação na fila se perde. Em produção, usaríamos um broker durável ou outbox; isso não é exigido pela atividade 7.

## Atributos e fluxo

O request REST traz `pedidoId`, `valor` e **`emailCliente`**. Incluímos o email porque o requisito RF04 precisa saber o destinatário. O domínio valida os campos e guarda as regras. O serviço de aplicação salva primeiro, publica na fila e devolve o UUID. O consumidor recebe o resultado do boleto, solicita a nota fiscal por porta SOAP, solicita a notificação por porta SMTP e persiste os resultados.

Status: `PENDENTE` → `PROCESSANDO` → `CONCLUIDA`. Se houver erro durante o processamento, passa para `FALHA` e armazena `erroProcessamento`.

## Testes

```powershell
.\mvnw.cmd test
```

- `FaturaTest`: validações de pedido, valor e e-mail; formatos de código, chave e hash.
- `FaturamentoIntegracaoTest`: cria fatura, aguarda consumidor e verifica dados persistidos.

## Diagramas extras

Na pasta `diagramas/` estão `arquitetura-hexagonal.mermaid` e `sequencia-faturamento.mermaid`, que podem ser abertos em um editor Mermaid (por exemplo, extensão Markdown/Mermaid no VS Code). Eles são explicativos; **o enunciado da Aula 7 não exige diagramas como entrega**.

## Publicação no GitHub

Copie a pasta `aula-7` para a raiz do repositório `Arquitetura-de-Software` sem apagar outras atividades. Na raiz do repositório:

```powershell
git add aula-7
git commit -m "Atividade 07 - Hub de integracoes hexagonal"
git push
```
