# Projeto Java da atividade 7

Consulte o [README da atividade](../README.md) para requisitos, execução, exemplos REST, limitações da simulação e publicação.
