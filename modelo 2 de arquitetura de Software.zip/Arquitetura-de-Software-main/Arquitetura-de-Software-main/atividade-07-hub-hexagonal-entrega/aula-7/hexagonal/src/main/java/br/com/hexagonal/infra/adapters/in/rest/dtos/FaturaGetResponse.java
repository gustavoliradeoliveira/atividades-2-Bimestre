package br.com.hexagonal.infra.adapters.in.rest.dtos;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import br.com.hexagonal.domain.entities.Fatura;
import br.com.hexagonal.domain.entities.StatusFatura;

public record FaturaGetResponse(
        String faturaId, Long pedidoId, BigDecimal valor, String emailCliente,
        StatusFatura status, String codigoBarras, String chaveAcessoNota,
        String hashEmail, LocalDateTime criadaEm, LocalDateTime emitidoEm,
        String erroProcessamento) {
    public static FaturaGetResponse doDominio(Fatura fatura) {
        return new FaturaGetResponse(fatura.getId().toString(), fatura.getPedidoId(),
            fatura.getValor(), fatura.getEmailCliente(), fatura.getStatus(),
            fatura.getCodigoBarras(), fatura.getChaveAcessoNota(),
            fatura.getHashEmail(), fatura.getCriadaEm(), fatura.getEmitidoEm(),
            fatura.getErroProcessamento());
    }
}
