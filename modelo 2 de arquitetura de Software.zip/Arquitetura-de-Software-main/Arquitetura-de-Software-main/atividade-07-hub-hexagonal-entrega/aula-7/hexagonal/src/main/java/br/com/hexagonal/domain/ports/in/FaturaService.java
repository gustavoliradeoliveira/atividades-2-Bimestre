package br.com.hexagonal.domain.ports.in;

import java.math.BigDecimal;
import java.util.Optional;
import java.util.UUID;
import br.com.hexagonal.domain.entities.Fatura;

public interface FaturaService {
    UUID faturarPedido(Long pedidoId, BigDecimal valor, String emailCliente);
    Optional<Fatura> consultarFatura(UUID id);
}
