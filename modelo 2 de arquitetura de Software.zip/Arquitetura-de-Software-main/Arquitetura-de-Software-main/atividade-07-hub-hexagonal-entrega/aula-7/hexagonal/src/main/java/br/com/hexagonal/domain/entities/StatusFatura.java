package br.com.hexagonal.domain.entities;

public enum StatusFatura {
    PENDENTE,
    PROCESSANDO,
    CONCLUIDA,
    FALHA
}
