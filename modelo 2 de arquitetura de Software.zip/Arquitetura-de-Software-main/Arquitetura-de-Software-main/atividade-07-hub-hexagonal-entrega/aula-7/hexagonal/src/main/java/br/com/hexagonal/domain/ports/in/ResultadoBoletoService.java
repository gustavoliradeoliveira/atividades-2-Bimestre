package br.com.hexagonal.domain.ports.in;

import java.util.UUID;

/** Porta de entrada chamada pelo consumidor simulado da fila. */
public interface ResultadoBoletoService {
    void receberBoletoEmitido(UUID faturaId, String codigoBarras);
    void registrarFalha(UUID faturaId, String motivo);
}
