package br.com.hexagonal.infra.adapters.in.rest.controllers;

import java.util.UUID;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.hexagonal.domain.ports.in.FaturaService;
import br.com.hexagonal.infra.adapters.in.rest.dtos.FaturaGetResponse;
import br.com.hexagonal.infra.adapters.in.rest.dtos.FaturaPostRequest;
import br.com.hexagonal.infra.adapters.in.rest.dtos.FaturaPostResponse;

@RestController
@RequestMapping("/fatura")
public class FaturaController {
    private final FaturaService faturaService;

    public FaturaController(FaturaService faturaService) {
        this.faturaService = faturaService;
    }

    @PostMapping
    public ResponseEntity<FaturaPostResponse> post(@RequestBody FaturaPostRequest request) {
        UUID id = faturaService.faturarPedido(request.pedidoId(), request.valor(), request.emailCliente());
        return ResponseEntity.status(201).body(new FaturaPostResponse(id.toString()));
    }

    @GetMapping("/{id}")
    public ResponseEntity<FaturaGetResponse> get(@PathVariable UUID id) {
        return faturaService.consultarFatura(id)
                .map(FaturaGetResponse::doDominio)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }
}
