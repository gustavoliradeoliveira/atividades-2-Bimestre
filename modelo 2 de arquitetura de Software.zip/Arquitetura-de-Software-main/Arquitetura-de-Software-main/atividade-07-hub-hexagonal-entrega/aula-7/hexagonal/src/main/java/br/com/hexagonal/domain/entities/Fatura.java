package br.com.hexagonal.domain.entities;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.UUID;

/** Regra de negócio sem dependência de Spring, JPA, SMTP, SOAP ou fila. */
public class Fatura {
    private final UUID id;
    private final Long pedidoId;
    private final BigDecimal valor;
    private final String emailCliente;
    private final LocalDateTime criadaEm;
    private LocalDateTime emitidoEm;
    private String codigoBarras;
    private String chaveAcessoNota;
    private String hashEmail;
    private StatusFatura status;
    private String erroProcessamento;

    private Fatura(UUID id, Long pedidoId, BigDecimal valor, String emailCliente,
                   LocalDateTime criadaEm, LocalDateTime emitidoEm,
                   String codigoBarras, String chaveAcessoNota, String hashEmail,
                   StatusFatura status, String erroProcessamento) {
        if (id == null) throw new IllegalArgumentException("O ID da fatura é obrigatório.");
        if (pedidoId == null || pedidoId <= 0) {
            throw new IllegalArgumentException("O pedidoId deve ser maior que zero.");
        }
        if (valor == null || valor.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("O valor deve ser maior que zero.");
        }
        if (emailCliente == null || !emailCliente.matches("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$")) {
            throw new IllegalArgumentException("Informe um emailCliente válido.");
        }
        this.id = id;
        this.pedidoId = pedidoId;
        this.valor = valor;
        this.emailCliente = emailCliente;
        this.criadaEm = criadaEm;
        this.emitidoEm = emitidoEm;
        this.codigoBarras = codigoBarras;
        this.chaveAcessoNota = chaveAcessoNota;
        this.hashEmail = hashEmail;
        this.status = status;
        this.erroProcessamento = erroProcessamento;
    }

    public static Fatura criar(Long pedidoId, BigDecimal valor, String emailCliente) {
        return new Fatura(UUID.randomUUID(), pedidoId, valor, emailCliente,
                LocalDateTime.now(), null, null, null, null, StatusFatura.PENDENTE, null);
    }

    /** Usado apenas pelo adaptador de persistência para reconstruir o domínio. */
    public static Fatura restaurar(UUID id, Long pedidoId, BigDecimal valor,
            String emailCliente, LocalDateTime criadaEm, LocalDateTime emitidoEm,
            String codigoBarras, String chaveAcessoNota, String hashEmail,
            StatusFatura status, String erroProcessamento) {
        return new Fatura(id, pedidoId, valor, emailCliente, criadaEm, emitidoEm,
                codigoBarras, chaveAcessoNota, hashEmail, status, erroProcessamento);
    }

    public void inserirBoleto(String codigoBarras) {
        exigirProcessamentoPermitido();
        if (codigoBarras == null || !codigoBarras.matches("\\d{44}")) {
            throw new IllegalArgumentException("O código de barras simulado deve ter 44 dígitos.");
        }
        this.codigoBarras = codigoBarras;
        this.status = StatusFatura.PROCESSANDO;
    }

    public void inserirNotaFiscal(String chaveAcessoNota) {
        exigirProcessamentoPermitido();
        if (chaveAcessoNota == null || !chaveAcessoNota.matches("\\d{44}")) {
            throw new IllegalArgumentException("A chave de acesso da nota deve ter 44 dígitos.");
        }
        this.chaveAcessoNota = chaveAcessoNota;
    }

    public void inserirHashEmail(String hashEmail) {
        exigirProcessamentoPermitido();
        if (hashEmail == null || !hashEmail.matches("[a-fA-F0-9]{64}")) {
            throw new IllegalArgumentException("O hash SHA-256 deve ter 64 caracteres hexadecimais.");
        }
        this.hashEmail = hashEmail.toLowerCase();
    }

    public void concluir() {
        exigirProcessamentoPermitido();
        if (codigoBarras == null || chaveAcessoNota == null || hashEmail == null) {
            throw new IllegalStateException("É necessário emitir boleto, nota e email antes de concluir.");
        }
        this.emitidoEm = LocalDateTime.now();
        this.status = StatusFatura.CONCLUIDA;
        this.erroProcessamento = null;
    }

    public void falhar(String motivo) {
        if (status != StatusFatura.CONCLUIDA) {
            this.status = StatusFatura.FALHA;
            this.erroProcessamento = motivo == null ? "Falha não identificada" : motivo;
        }
    }

    private void exigirProcessamentoPermitido() {
        if (status == StatusFatura.CONCLUIDA || status == StatusFatura.FALHA) {
            throw new IllegalStateException("Esta fatura não pode mais ser processada.");
        }
    }

    public UUID getId() { return id; }
    public Long getPedidoId() { return pedidoId; }
    public BigDecimal getValor() { return valor; }
    public String getEmailCliente() { return emailCliente; }
    public LocalDateTime getCriadaEm() { return criadaEm; }
    public LocalDateTime getEmitidoEm() { return emitidoEm; }
    public String getCodigoBarras() { return codigoBarras; }
    public String getChaveAcessoNota() { return chaveAcessoNota; }
    public String getHashEmail() { return hashEmail; }
    public StatusFatura getStatus() { return status; }
    public String getErroProcessamento() { return erroProcessamento; }
}
