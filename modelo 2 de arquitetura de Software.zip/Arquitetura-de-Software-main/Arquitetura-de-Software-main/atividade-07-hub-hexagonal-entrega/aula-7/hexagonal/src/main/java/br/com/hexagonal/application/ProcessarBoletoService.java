package br.com.hexagonal.application;

import java.util.UUID;
import org.springframework.stereotype.Service;

import br.com.hexagonal.domain.entities.Fatura;
import br.com.hexagonal.domain.ports.in.ResultadoBoletoService;
import br.com.hexagonal.domain.ports.out.persistence.FaturaRepository;
import br.com.hexagonal.domain.ports.out.soap.NotaFiscalSoap;
import br.com.hexagonal.domain.ports.out.smtp.EmailSmtp;

/** Orquestra o resultado da fila e as integrações sem conhecer tecnologias concretas. */
@Service
public class ProcessarBoletoService implements ResultadoBoletoService {
    private final FaturaRepository repository;
    private final NotaFiscalSoap notaFiscalSoap;
    private final EmailSmtp emailSmtp;

    public ProcessarBoletoService(FaturaRepository repository,
                                 NotaFiscalSoap notaFiscalSoap, EmailSmtp emailSmtp) {
        this.repository = repository;
        this.notaFiscalSoap = notaFiscalSoap;
        this.emailSmtp = emailSmtp;
    }

    @Override
    public void receberBoletoEmitido(UUID faturaId, String codigoBarras) {
        Fatura fatura = repository.buscarPorId(faturaId)
                .orElseThrow(() -> new IllegalArgumentException("Fatura não encontrada: " + faturaId));
        if (fatura.getStatus() == br.com.hexagonal.domain.entities.StatusFatura.CONCLUIDA) return;

        fatura.inserirBoleto(codigoBarras);
        repository.salvar(fatura); // RF02: código de barras guardado na fatura

        String chaveAcesso = notaFiscalSoap.emitirNota(fatura);
        fatura.inserirNotaFiscal(chaveAcesso);
        repository.salvar(fatura); // RF03: chave da nota guardada na fatura

        String hash = emailSmtp.notificarCliente(fatura);
        fatura.inserirHashEmail(hash);
        fatura.concluir();
        repository.salvar(fatura); // RF04: hash guardado e fatura concluída
    }

    @Override
    public void registrarFalha(UUID faturaId, String motivo) {
        repository.buscarPorId(faturaId).ifPresent(fatura -> {
            fatura.falhar(motivo);
            repository.salvar(fatura);
        });
    }
}
