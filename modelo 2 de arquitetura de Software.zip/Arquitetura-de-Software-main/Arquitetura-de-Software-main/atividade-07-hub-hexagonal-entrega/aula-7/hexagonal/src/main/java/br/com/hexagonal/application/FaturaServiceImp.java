package br.com.hexagonal.application;

import java.math.BigDecimal;
import java.util.Optional;
import java.util.UUID;
import org.springframework.stereotype.Service;

import br.com.hexagonal.domain.entities.Fatura;
import br.com.hexagonal.domain.ports.in.FaturaService;
import br.com.hexagonal.domain.ports.out.messaging.BoletoMessaging;
import br.com.hexagonal.domain.ports.out.persistence.FaturaRepository;

@Service
public class FaturaServiceImp implements FaturaService {
    private final FaturaRepository repository;
    private final BoletoMessaging filaBoleto;

    public FaturaServiceImp(FaturaRepository repository, BoletoMessaging filaBoleto) {
        this.repository = repository;
        this.filaBoleto = filaBoleto;
    }

    @Override
    public UUID faturarPedido(Long pedidoId, BigDecimal valor, String emailCliente) {
        Fatura fatura = Fatura.criar(pedidoId, valor, emailCliente);
        repository.salvar(fatura); // RF01: persiste antes de devolver o ID
        filaBoleto.solicitarEmissao(fatura.getId()); // RF02: publica na fila simulada
        return fatura.getId();
    }

    @Override
    public Optional<Fatura> consultarFatura(UUID id) {
        return repository.buscarPorId(id);
    }
}
