package br.com.hexagonal;

import static org.junit.jupiter.api.Assertions.*;
import java.math.BigDecimal;
import java.time.Duration;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import br.com.hexagonal.domain.entities.Fatura;
import br.com.hexagonal.domain.entities.StatusFatura;
import br.com.hexagonal.domain.ports.in.FaturaService;

@SpringBootTest
@TestPropertySource(properties = {
    "spring.datasource.url=jdbc:h2:mem:atividade7;DB_CLOSE_DELAY=-1",
    "spring.jpa.hibernate.ddl-auto=create-drop"
})
class FaturamentoIntegracaoTest {
    @Autowired FaturaService faturaService;

    @Test
    void faturaEPreencheCamposComAdaptadoresSimulados() throws Exception {
        UUID id = faturaService.faturarPedido(1001L, new BigDecimal("199.90"), "cliente@teste.com");
        Fatura atual = null;
        long limite = System.nanoTime() + Duration.ofSeconds(8).toNanos();
        while (System.nanoTime() < limite) {
            atual = faturaService.consultarFatura(id).orElseThrow();
            if (atual.getStatus() == StatusFatura.CONCLUIDA || atual.getStatus() == StatusFatura.FALHA) break;
            Thread.sleep(50);
        }
        assertNotNull(atual);
        assertEquals(StatusFatura.CONCLUIDA, atual.getStatus(), "Erro: " + atual.getErroProcessamento());
        assertTrue(atual.getCodigoBarras().matches("\\d{44}"));
        assertTrue(atual.getChaveAcessoNota().matches("\\d{44}"));
        assertTrue(atual.getHashEmail().matches("[a-f0-9]{64}"));
    }
}
