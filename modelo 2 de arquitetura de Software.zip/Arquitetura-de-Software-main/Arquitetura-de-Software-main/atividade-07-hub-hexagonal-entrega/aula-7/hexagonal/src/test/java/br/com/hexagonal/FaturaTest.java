package br.com.hexagonal;

import static org.junit.jupiter.api.Assertions.*;
import java.math.BigDecimal;
import org.junit.jupiter.api.Test;
import br.com.hexagonal.domain.entities.Fatura;
import br.com.hexagonal.domain.entities.StatusFatura;

class FaturaTest {
    @Test
    void criaFaturaPendente() {
        Fatura f = Fatura.criar(42L, new BigDecimal("125.00"), "cliente@teste.com");
        assertNotNull(f.getId());
        assertEquals(StatusFatura.PENDENTE, f.getStatus());
        assertNull(f.getCodigoBarras());
    }

    @Test
    void validaPedidoValorEEmail() {
        assertThrows(IllegalArgumentException.class,
                () -> Fatura.criar(0L, BigDecimal.TEN, "cliente@teste.com"));
        assertThrows(IllegalArgumentException.class,
                () -> Fatura.criar(1L, BigDecimal.ZERO, "cliente@teste.com"));
        assertThrows(IllegalArgumentException.class,
                () -> Fatura.criar(1L, BigDecimal.TEN, "invalido"));
    }

    @Test
    void exigeChaveNotaDe44DigitosEHashDe64Hexadecimais() {
        Fatura f = Fatura.criar(7L, BigDecimal.TEN, "cliente@teste.com");
        assertThrows(IllegalArgumentException.class, () -> f.inserirBoleto("123"));
        assertThrows(IllegalArgumentException.class, () -> f.inserirNotaFiscal("chave-curta"));
        assertThrows(IllegalArgumentException.class, () -> f.inserirHashEmail("x"));
        f.inserirBoleto("1".repeat(44));
        f.inserirNotaFiscal("2".repeat(44));
        f.inserirHashEmail("a".repeat(64));
        f.concluir();
        assertEquals(StatusFatura.CONCLUIDA, f.getStatus());
    }
}
